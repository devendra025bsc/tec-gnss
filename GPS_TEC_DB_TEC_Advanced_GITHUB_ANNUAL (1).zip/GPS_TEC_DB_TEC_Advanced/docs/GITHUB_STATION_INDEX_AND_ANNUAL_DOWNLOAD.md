# GitHub station index + annual official RINEX downloads

## Architecture

- GitHub stores a small JSON station metadata catalogue, not the daily observation archive.
- The desktop app loads a public GitHub **raw JSON URL** and uses the index for quick station-name/code searches.
- The annual downloader checks every UTC day against the selected official BKG HTTPS network and downloads files that the archive actually lists.
- Every run writes a CSV manifest with one row per day (`downloaded`, `already_present`, `not_found`, `download_failed`, or `search_failed`). Missing files are recorded; the application does not invent or silently substitute observations.
- Downloaded files are saved to `<chosen output>/<STATION>/<YEAR>/`.

## Publish the index on GitHub

1. Create a repository you control, for example `gnss-station-index`.
2. Copy `github_index/stations.example.json` to `stations.json` and update station names, network labels and metadata from authoritative station lists.
3. Commit and push `stations.json`.
4. Open the file on GitHub and choose **Raw**. Copy the raw HTTPS URL. It usually looks like `https://raw.githubusercontent.com/OWNER/REPOSITORY/BRANCH/stations.json`.
5. In the app select **GitHub station index + DOWNLOAD FULL YEAR**, paste the raw URL and click **LOAD / REFRESH INDEX**.

The sample catalogue is a template, not an authoritative proof that all listed stations were active for all dates. Confirm coordinates and metadata from the relevant network before scientific use.

## Download one station for one year

1. Load the GitHub index, select a result or type the station code.
2. Enter the year and select the official BKG network (`IGS`, `EUREF`, `MGEX`, `GREF`, or `IGLOS`).
3. Choose a local output directory and start the annual search/download.
4. Review the manifest CSV for missing dates, download errors and duplicate/local files.

The app searches the archive by day. A full year can take minutes to much longer depending on archive response and network speed. The UI runs the work in a background thread; it does not guarantee that a complete year exists. If the provider's archive layout changes, the manifest reports the errors for review.

## Storage and GitHub limits

Do not commit an entire year of RINEX files to the station-index repository. RINEX data can be large, may be subject to provider terms, and GitHub repositories are not designed as bulk scientific data archives. Keep only metadata/indexes in GitHub and fetch observations from the official archive. Use a dedicated scientific data repository/object store only if a durable mirror is needed and redistribution is permitted.

## JSON schema

```json
{
  "version": 1,
  "stations": [
    {"station": "NIST", "name": "Station name", "network": "IGS", "country": "USA", "provider": "BKG HTTPS archive"}
  ]
}
```

The index is metadata for discovery only. The application always verifies the actual date-specific observation file against the official archive before downloading.
