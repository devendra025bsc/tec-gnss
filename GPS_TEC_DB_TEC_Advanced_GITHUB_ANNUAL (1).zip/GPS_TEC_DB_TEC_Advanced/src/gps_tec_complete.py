#!/usr/bin/env python3
"""Complete GPS-only RINEX -> STEC/VTEC processor.

Designed for RINEX 2/3 GPS observations and broadcast GPS navigation.
Implements:
- C1/P2 -> P1/P2 consistency correction using CODE P1-C1 satellite DCB
- CODE P1-P2 satellite and receiver DCB correction
- L1/L2 carrier-phase geometry-free TEC
- cycle-slip/arc detection
- carrier-phase leveling to corrected code TEC
- broadcast-ephemeris satellite position and actual elevation
- elevation mask and 350-km thin-shell mapping
- epoch satellite averaging and optional 15-minute product
- publication-quality PNG and CSV outputs

The program does not apply arbitrary min/max TEC normalization.
"""
from __future__ import annotations
import argparse, bisect, gzip, logging, math, os, re, sys, urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

log = logging.getLogger(__name__)

C = 299792458.0
F1 = 1575.42e6
F2 = 1227.60e6
L1 = C / F1
L2 = C / F2
K = 40.3
TECU = 1e16
RE_KM = 6371.0
SHELL_KM = 350.0
DEFAULT_ELEV_MASK = 10.0

# CODE archive names used historically by GPS-TEC workflows.
# Prefer the AIUB HTTPS download service.  The legacy ftp.aiub.unibe.ch
# endpoint can time out on some networks, so it is deliberately not used.
CODE_BASES = [
    "https://www.aiub.unibe.ch/download/CODE/{year}/{name}",
    "http://www.aiub.unibe.ch/download/CODE/{year}/{name}",
]


def dexp(x):
    x = x.strip().replace("D", "E").replace("d", "e")
    return float(x) if x else np.nan


def download(url, out):
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "GPS-TEC-Complete/1.0"})
    with urllib.request.urlopen(req, timeout=10) as r, open(out, "wb") as f:
        f.write(r.read())
    return out


def lzw_decompress(data: bytes) -> bytes:
    """Pure-Python Unix .Z (compress/LZW) decoder; supports block mode."""
    if len(data) < 3 or data[:2] != b"\x1f\x9d":
        return data
    maxbits = data[2] & 0x1f
    block = bool(data[2] & 0x80)
    if not 9 <= maxbits <= 16:
        raise ValueError("Unsupported .Z maxbits")
    pos = 3
    CLEAR = 256
    free_ent = 257 if block else 256
    n_bits = 9
    maxcode = (1 << n_bits) - 1
    maxmaxcode = 1 << maxbits
    prefix = [0] * maxmaxcode
    suffix = bytearray(maxmaxcode)
    stack = bytearray(maxmaxcode + 1)
    datum = 0
    bits = 0
    oldcode = -1
    finchar = 0
    out = bytearray()

    def read_code():
        nonlocal datum, bits, pos, n_bits
        while bits < n_bits:
            if pos >= len(data):
                return None
            datum |= data[pos] << bits
            pos += 1
            bits += 8
        code = datum & ((1 << n_bits) - 1)
        datum >>= n_bits
        bits -= n_bits
        return code

    while True:
        code = read_code()
        if code is None:
            break
        if block and code == CLEAR:
            n_bits = 9
            maxcode = (1 << n_bits) - 1
            free_ent = 257
            oldcode = -1
            continue
        if oldcode == -1:
            if code >= 256:
                raise ValueError("Invalid first LZW code")
            out.append(code)
            finchar = code
            oldcode = code
            continue
        incode = code
        sp = 0
        if code >= free_ent:
            if code != free_ent:
                raise ValueError("Invalid LZW code")
            stack[sp] = finchar
            sp += 1
            code = oldcode
        while code >= 256:
            stack[sp] = suffix[code]
            sp += 1
            code = prefix[code]
        finchar = code
        stack[sp] = finchar
        sp += 1
        while sp:
            sp -= 1
            out.append(stack[sp])
        if free_ent < maxmaxcode:
            prefix[free_ent] = oldcode
            suffix[free_ent] = finchar
            free_ent += 1
            if free_ent > maxcode and n_bits < maxbits:
                n_bits += 1
                maxcode = (1 << n_bits) - 1
        oldcode = incode
    return bytes(out)


def read_text_file(path):
    """Read plain, gzip, Unix .Z, Hatanaka .crx and Hatanaka .crx.gz RINEX.

    Hatanaka decompression is handled with the cross-platform ``hatanaka``
    package when available.  The rest of the processing remains independent
    of the compression format.
    """
    path = Path(path)
    raw = path.read_bytes()
    name = path.name.lower()

    if name.endswith(".crx.gz") or name.endswith(".crx"):
        try:
            import hatanaka
            raw = hatanaka.decompress(raw)
        except Exception as exc:
            raise RuntimeError(
                f"Cannot decompress Hatanaka RINEX {path.name}. "
                "Install the 'hatanaka' package."
            ) from exc
    elif name.endswith(".gz"):
        raw = gzip.decompress(raw)
        # A few archives contain .crx.gz where the suffix is hidden by
        # an unusual filename. Detect the Hatanaka RINEX marker and decode.
        if raw.startswith(b"     3.") and b"COMPACT" in raw[:4000]:
            try:
                import hatanaka
                raw = hatanaka.decompress(raw)
            except Exception:
                pass
    elif name.endswith(".z"):
        raw = lzw_decompress(raw)

    return raw.decode("ascii", errors="ignore")


def dcb_download(date, dcb_dir):
    """Download CODE monthly DCB files with short, fail-fast networking.

    Monthly CODE DCB products are preferred because they match the observation
    month.  The downloader tries the AIUB HTTPS service first and uses the
    legacy FTP server only as a final fallback.  A failed network source does
    not cause repeated long waits.  Existing files in ``dcb_dir`` are always
    reused first, which also supports fully offline processing.
    """
    year = date.year
    yy = str(year)[-2:]
    mm = f"{date.month:02d}"
    dcb_dir = Path(dcb_dir)
    dcb_dir.mkdir(parents=True, exist_ok=True)

    # Required monthly CODE products for this processor.
    wanted = [f"P1C1{yy}{mm}.DCB", f"P1P2{yy}{mm}_ALL.DCB"]
    candidates = []
    for plain in wanted:
        candidates.extend([plain, plain + ".Z"])
    # Accept the satellite-only P1-P2 file as a fallback when the _ALL file
    # is unavailable; receiver DCB then remains zero rather than inventing it.
    candidates.extend([f"P1P2{yy}{mm}.DCB", f"P1P2{yy}{mm}.DCB.Z"])

    def existing_for(prefixes):
        for n in prefixes:
            p = dcb_dir / n
            if p.exists() and p.stat().st_size > 0:
                return p
        return None

    p1c1 = existing_for([f"P1C1{yy}{mm}.DCB", f"P1C1{yy}{mm}.DCB.Z"])
    p1p2_all = existing_for([f"P1P2{yy}{mm}_ALL.DCB", f"P1P2{yy}{mm}_ALL.DCB.Z"])
    p1p2 = existing_for([f"P1P2{yy}{mm}.DCB", f"P1P2{yy}{mm}.DCB.Z"])

    if p1c1 and (p1p2_all or p1p2):
        log.info("Using cached CODE DCB: %s, %s", p1c1.name, (p1p2_all or p1p2).name)
        return p1c1, p1p2_all or p1p2

    def fetch_one(base_names, label):
        # Try compressed monthly product first, then uncompressed.  Only the
        # current AIUB HTTPS/HTTP web service is used here; the legacy FTP
        # service is intentionally excluded because it can hang/time out.
        for name in base_names:
            for tmpl in CODE_BASES:
                url = tmpl.format(year=year, name=name)
                target = dcb_dir / name
                try:
                    log.debug("Fetching DCB: %s", url)
                    download(url, target)
                    if target.exists() and target.stat().st_size > 0:
                        log.info("DCB downloaded: %s", target.name)
                        return target
                    target.unlink(missing_ok=True)
                except Exception as exc:
                    target.unlink(missing_ok=True)
                    log.debug("DCB source failed (%s): %s", type(exc).__name__, exc)
        log.warning("Could not automatically obtain %s for %s-%s.", label, year, mm)
        return None

    if p1c1 is None:
        p1c1 = fetch_one(
            [f"P1C1{yy}{mm}.DCB.Z", f"P1C1{yy}{mm}.DCB"],
            f"P1C1{yy}{mm}.DCB(.Z)",
        )
    if p1p2_all is None and p1p2 is None:
        p1p2_all = fetch_one(
            [f"P1P2{yy}{mm}_ALL.DCB.Z", f"P1P2{yy}{mm}_ALL.DCB",
             f"P1P2{yy}{mm}.DCB.Z", f"P1P2{yy}{mm}.DCB"],
            f"P1P2{yy}{mm}_ALL.DCB(.Z)",
        )

    return p1c1, p1p2_all or p1p2


def parse_code_dcb(path):
    """Parse legacy CODE DCB ASCII into satellite and station maps in ns.

    The Bernese/CODE format uses lines such as:
      G01  -8.540  0.012
      G  ABMF 97103M001  -10.423  0.093
    Older files may omit the leading G for satellites.
    """
    if path is None:
        return {}, {}
    text = read_text_file(path)
    sats, stations = {}, {}
    for raw in text.splitlines():
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        # GPS satellite at beginning, with or without G prefix.
        m = re.match(r"^(G?\d{1,2})\s+([-+]?\d+(?:\.\d*)?(?:[EeDd][-+]?\d+)?)\s+([-+]?\d+(?:\.\d*)?(?:[EeDd][-+]?\d+)?)", s)
        if m:
            prn = m.group(1).upper()
            if not prn.startswith("G"):
                prn = "G" + prn.zfill(2)
            sats[prn] = dexp(m.group(2))
            continue
        # Station lines. Keep the first four-character station token.
        m = re.match(r"^G\s+([A-Za-z0-9]{4})(?:\s+\S+)?\s+([-+]?\d+(?:\.\d*)?(?:[EeDd][-+]?\d+)?)\s+", s)
        if m:
            stations[m.group(1).upper()] = dexp(m.group(2))
            continue
        # Some variants are: G STATION VALUE RMS.
        m = re.match(r"^G\s+([A-Za-z0-9]{4})\s+([-+]?\d+(?:\.\d*)?(?:[EeDd][-+]?\d+)?)\s+", s)
        if m:
            stations[m.group(1).upper()] = dexp(m.group(2))
    return sats, stations


def find_station_code(obs_path):
    for line in read_text_file(obs_path).splitlines()[:100]:
        if "MARKER NAME" in line:
            return line[:60].strip().split()[0].upper()
    return Path(obs_path).name[:4].upper()


def parse_obs_header(text):
    lines = text.splitlines()
    version = float(lines[0][0:9].strip())
    end = next(i for i, l in enumerate(lines) if "END OF HEADER" in l)
    if version < 3:
        obs_types = []
        for l in lines[:end]:
            if "# / TYPES OF OBSERV" in l:
                n = int(l[0:6])
                for k in range(6, 60, 6):
                    x = l[k:k+6].strip()
                    if x:
                        obs_types.append(x)
                # continuation lines
                j = lines.index(l) + 1
                while len(obs_types) < n and j < end:
                    for k in range(6, 60, 6):
                        x = lines[j][k:k+6].strip()
                        if x:
                            obs_types.append(x)
                    j += 1
                obs_types = obs_types[:n]
                break
        xyz = None
        for l in lines[:end]:
            if "APPROX POSITION XYZ" in l:
                try:
                    xyz = np.array([float(l[0:14]), float(l[14:28]), float(l[28:42])])
                except Exception:
                    pass
        return version, end, obs_types, xyz
    else:
        obs_types = {}
        xyz = None
        i = 0
        while i < end:
            l = lines[i]
            if "SYS / # / OBS TYPES" in l:
                sysc = l[0]
                n = int(l[3:6])
                vals = []
                for k in range(7, 60, 4):
                    x = l[k:k+4].strip()
                    if x:
                        vals.append(x)
                while len(vals) < n:
                    i += 1
                    ll = lines[i]
                    for k in range(7, 60, 4):
                        x = ll[k:k+4].strip()
                        if x:
                            vals.append(x)
                obs_types[sysc] = vals[:n]
            if "APPROX POSITION XYZ" in l:
                try:
                    xyz = np.array([float(l[0:14]), float(l[14:28]), float(l[28:42])])
                except Exception:
                    pass
            i += 1
        return version, end, obs_types, xyz


def pick_obs(types, candidates):
    for c in candidates:
        if c in types:
            return types.index(c)
    return None


def parse_rinex2(text):
    lines = text.splitlines()
    version, end, types, xyz = parse_obs_header(text)
    idx = {name: i for i, name in enumerate(types)}
    p1 = pick_obs(types, ["P1", "C1"])
    p2 = pick_obs(types, ["P2", "C2"])
    l1 = pick_obs(types, ["L1"])
    l2 = pick_obs(types, ["L2"])
    if None in (p1, p2, l1, l2):
        raise RuntimeError(f"RINEX2 missing required GPS observables: P1/C1={p1}, P2/C2={p2}, L1={l1}, L2={l2}")
    rows = []
    i = end + 1
    while i < len(lines):
        l = lines[i]
        if len(l) < 32 or not l[1:3].strip().lstrip("-").isdigit():
            i += 1; continue
        try:
            yy = int(l[1:3]); year = 2000 + yy if yy < 80 else 1900 + yy
            epoch = pd.Timestamp(year, int(l[4:6]), int(l[7:9]), int(l[10:12]), int(l[13:15]), int(float(l[15:26])))
            flag = int(l[28:29]); nsat = int(l[29:32])
        except Exception:
            i += 1; continue
        sat_ids = []
        part = l[32:]
        for k in range(0, len(part), 3):
            x = part[k:k+3].strip()
            if x: sat_ids.append(x)
        while len(sat_ids) < nsat and i + 1 < len(lines):
            i += 1
            part = lines[i]
            for k in range(0, len(part), 3):
                x = part[k:k+3].strip()
                if x: sat_ids.append(x)
        i += 1
        if flag not in (0, 1):
            i += nsat * math.ceil(len(types) / 5)
            continue
        nobs_lines = math.ceil(len(types) / 5)
        for sid in sat_ids[:nsat]:
            blob = ""
            for _ in range(nobs_lines):
                if i >= len(lines): break
                blob += lines[i].ljust(80); i += 1
            vals = []
            for k in range(len(types)):
                field = blob[k*16:(k+1)*16]
                vals.append(dexp(field[:14]) if field[:14].strip() else np.nan)
            if sid.startswith("G"):
                prn = sid
            elif sid.isdigit():
                prn = "G" + sid.zfill(2)
            else:
                continue
            if max(p1,p2,l1,l2) >= len(vals): continue
            if all(np.isfinite(vals[j]) for j in (p1,p2,l1,l2)):
                rows.append((epoch, prn, vals[p1], vals[p2], vals[l1], vals[l2]))
    return pd.DataFrame(rows, columns=["datetime","PRN","C1","P2","L1","L2"]), xyz


def parse_rinex3(text):
    lines = text.splitlines()
    version, end, types, xyz = parse_obs_header(text)
    gps = types.get("G", [])
    p1 = pick_obs(gps, ["C1W", "C1C", "C1X", "P1"])
    p2 = pick_obs(gps, ["C2W", "C2X", "C2L", "P2"])
    l1 = pick_obs(gps, ["L1W", "L1C", "L1X"])
    l2 = pick_obs(gps, ["L2W", "L2X", "L2C"])
    if None in (p1,p2,l1,l2):
        raise RuntimeError(f"RINEX3 missing GPS observables: {gps}")
    rows=[]; i=end+1
    while i < len(lines):
        if not lines[i].startswith(">"):
            i+=1; continue
        parts=lines[i].split(); i+=1
        if len(parts)<8: continue
        try:
            epoch=pd.Timestamp(int(parts[1]),int(parts[2]),int(parts[3]),int(parts[4]),int(parts[5]),int(float(parts[6])))
            flag=int(parts[7]); nsat=int(parts[8]) if len(parts)>8 else 0
        except Exception: continue
        if flag not in (0,1):
            i += nsat
            continue
        for _ in range(nsat):
            if i>=len(lines): break
            l=lines[i]; i+=1
            if not l.startswith("G"): continue
            prn=l[0:3]
            blob=l[3:]
            need=len(gps)*16
            while len(blob)<need and i<len(lines):
                blob += lines[i]; i+=1
            vals=[]
            for k in range(len(gps)):
                field=blob[k*16:(k+1)*16]
                vals.append(dexp(field[:14]) if field[:14].strip() else np.nan)
            if max(p1,p2,l1,l2)<len(vals) and all(np.isfinite(vals[j]) for j in (p1,p2,l1,l2)):
                rows.append((epoch,prn,vals[p1],vals[p2],vals[l1],vals[l2]))
    return pd.DataFrame(rows, columns=["datetime","PRN","C1","P2","L1","L2"]), xyz


def read_obs(path):
    text=read_text_file(path)
    version=float(text[:9].strip())
    if version < 3: return parse_rinex2(text)
    return parse_rinex3(text)



def nav_download(date, nav_dir):
    """Download a daily GPS broadcast navigation file from NOAA/BKG."""
    nav_dir = Path(nav_dir); nav_dir.mkdir(parents=True, exist_ok=True)
    year=date.year; doy=date.timetuple().tm_yday; yy=str(year)[-2:]
    names=[f"brdc{doy:03d}0.{yy}n.gz", f"BRDC00WRD_S_{year}{doy:03d}0000_01D_MN.rnx.gz", f"BRDC00IGS_R_{year}{doy:03d}0000_01D_MN.rnx.gz"]
    urls=[
      f"https://geodesy.noaa.gov/corsdata/rinex/{year}/{doy:03d}/{names[0]}",
      f"https://igs.bkg.bund.de/root_ftp/IGS/BRDC/{year}/{doy:03d}/{names[1]}",
      f"https://igs.bkg.bund.de/root_ftp/IGS/BRDC/{year}/{doy:03d}/{names[2]}",
      f"https://cddis.nasa.gov/archive/gnss/data/daily/{year}/{doy:03d}/{yy}n/{names[0]}"
    ]
    for name in names:
        for p in (nav_dir/name, nav_dir/name[:-3]):
            if p.exists(): return p
    for url in urls:
        try:
            target=nav_dir/Path(url).name
            log.debug("Fetching navigation: %s", url)
            download(url,target)
            raw=target.read_bytes()
            if target.suffix.lower()=='.gz':
                raw=gzip.decompress(raw); plain=target.with_suffix('')
                plain.write_bytes(raw); return plain
            return target
        except Exception as exc:
            log.debug("Navigation source failed: %s", exc)
    raise RuntimeError("Could not download broadcast navigation. Supply --nav manually.")

def parse_nav(path):
    text=read_text_file(path); lines=text.splitlines()
    end=next(i for i,l in enumerate(lines) if "END OF HEADER" in l)
    eph=[]; i=end+1
    while i+7<len(lines):
        l=lines[i]
        try:
            if l.startswith("G"):
                t=l.split(); prn=int(t[0][1:]); year=int(t[1]); month=int(t[2]); day=int(t[3]); hour=int(t[4]); minute=int(t[5]); sec=float(t[6]); vals=[dexp(x) for x in t[7:10]]
            else:
                prn=int(l[0:2]); year=int(l[3:5]); year=2000+year if year<80 else 1900+year; month=int(l[6:8]); day=int(l[9:11]); hour=int(l[12:14]); minute=int(l[15:17]); sec=float(l[18:22]); vals=[dexp(l[22:41]),dexp(l[41:60]),dexp(l[60:79])]
            if l.startswith("G"): year = int(t[1])
            rec={"prn":prn,"toc":pd.Timestamp(year,month,day,hour,minute,int(sec)),"af0":vals[0],"af1":vals[1],"af2":vals[2]}
            if l.startswith("G"):
                rows=[ [dexp(x) for x in lines[i+j].split()[:4]] for j in range(1,8)]
            else:
                rows=[[dexp(lines[i+j][3+k*19:22+k*19]) for k in range(4)] for j in range(1,8)]
            rec.update({"Crs":rows[0][1],"dn":rows[0][2],"M0":rows[0][3],"Cuc":rows[1][0],"e":rows[1][1],"Cus":rows[1][2],"sqrtA":rows[1][3],"Toe":rows[2][0],"Cic":rows[2][1],"Omega0":rows[2][2],"Cis":rows[2][3],"i0":rows[3][0],"Crc":rows[3][1],"omega":rows[3][2],"OmegaDot":rows[3][3],"IDOT":rows[4][0],"GPSweek":rows[5][2],"TGD":rows[6][2]})
            eph.append(rec); i+=8
        except Exception:
            i+=8
    return eph


def sat_xyz(e, epoch):
    A=e["sqrtA"]**2; mu=3.986005e14; we=7.2921151467e-5
    gps0=pd.Timestamp("1980-01-06"); sec=(epoch-gps0).total_seconds(); week=math.floor(sec/604800); tow=sec-week*604800
    tk=tow-e["Toe"]
    if tk>302400: tk-=604800
    if tk<-302400: tk+=604800
    n=math.sqrt(mu/A**3)+e["dn"]; M=e["M0"]+n*tk; E=M
    for _ in range(20):
        ne=E-(E-e["e"]*math.sin(E)-M)/(1-e["e"]*math.cos(E));
        if abs(ne-E)<1e-13: E=ne; break
        E=ne
    v=math.atan2(math.sqrt(1-e["e"]**2)*math.sin(E), math.cos(E)-e["e"])
    phi=v+e["omega"]; sh=math.sin(2*phi); ch=math.cos(2*phi)
    u=phi+e["Cus"]*sh+e["Cuc"]*ch; r=A*(1-e["e"]*math.cos(E))+e["Crs"]*sh+e["Crc"]*ch; inc=e["i0"]+e["IDOT"]*tk+e["Cis"]*sh+e["Cic"]*ch
    xo=r*math.cos(u); yo=r*math.sin(u); Om=e["Omega0"]+(e["OmegaDot"]-we)*tk-we*e["Toe"]
    return np.array([xo*math.cos(Om)-yo*math.cos(inc)*math.sin(Om), xo*math.sin(Om)+yo*math.cos(inc)*math.cos(Om), yo*math.sin(inc)])


def elevation(rx, sv):
    x,y,z=rx; lon=math.atan2(y,x); p=math.hypot(x,y); a=6378137.; e2=6.69437999014e-3; lat=math.atan2(z,p*(1-e2))
    for _ in range(10):
        N=a/math.sqrt(1-e2*math.sin(lat)**2); h=p/math.cos(lat)-N; lat=math.atan2(z,p*(1-e2*N/(N+h)))
    d=sv-rx; sl,cl,so,co=math.sin(lat),math.cos(lat),math.sin(lon),math.cos(lon)
    east=-so*d[0]+co*d[1]; north=-sl*co*d[0]-sl*so*d[1]+cl*d[2]; up=cl*co*d[0]+cl*so*d[1]+sl*d[2]
    return math.degrees(math.atan2(up,math.hypot(east,north)))


def map_factor(el):
    arr=np.asarray(el, dtype=float)
    # Optional GPU path for genuinely large vector operations. Small arrays stay
    # on CPU because PCIe transfer overhead would make them slower.
    if arr.size >= 100000 and os.environ.get("GPS_TEC_GPU", "auto").lower() != "off":
        try:
            import cupy as cp
            a=cp.radians(cp.asarray(arr)); q=RE_KM*cp.cos(a)/(RE_KM+SHELL_KM)
            return cp.asnumpy(cp.sqrt(cp.maximum(0,1-q*q)))
        except Exception:
            pass
    a=np.radians(arr); q=RE_KM*np.cos(a)/(RE_KM+SHELL_KM)
    return np.sqrt(np.maximum(0,1-q*q))


def code_stec_c1p2(c1,p2,p1c1_sat_ns,p1p2_sat_ns,p1p2_rx_ns):
    # Convert C1 to P1 using satellite P1-C1 DCB, then remove P1-P2 DCB.
    p1=c1 + C*p1c1_sat_ns*1e-9
    gf=p2-p1
    # CODE DCB convention is P1-P2; ionospheric P2-P1 term is gf + DCB(P1-P2).
    gf_corr=gf + C*(p1p2_sat_ns+p1p2_rx_ns)*1e-9
    denom=K*(1/F1**2-1/F2**2)
    return gf_corr/denom/TECU


def phase_stec(l1,l2):
    gf=l1*L1-l2*L2
    denom=K*(1/F1**2-1/F2**2)
    return -gf/denom/TECU


def nearest_eph(eph, prn, t):
    arr=[e for e in eph if e["prn"]==int(prn[1:])]
    if not arr: return None
    return min(arr,key=lambda e:abs((t-e["toc"]).total_seconds()))

def build_eph_index(eph):
    idx={}
    for e in eph:
        idx.setdefault(int(e["prn"]), []).append(e)
    for k in idx:
        idx[k].sort(key=lambda e:e["toc"])
    return idx

def nearest_eph_indexed(index, prn, t):
    arr=index.get(int(prn[1:]), [])
    if not arr: return None
    keys=[e["toc"] for e in arr]
    i=bisect.bisect_left(keys, t)
    if i<=0: return arr[0]
    if i>=len(arr): return arr[-1]
    a,b=arr[i-1],arr[i]
    return a if abs((t-a["toc"]).total_seconds()) <= abs((b["toc"]-t).total_seconds()) else b


def process_satellite(g, elev=None, slip_threshold=0.75, level_mode="daily", min_level_points=10):
    """Detect phase arcs and level carrier-phase STEC to corrected code STEC.

    level_mode="daily" is the recommended storm-study mode.  Each UTC day
    and each satellite is levelled independently so that a receiver/data
    discontinuity at midnight cannot transfer an offset from one day to the
    next.  Within a day, cycle-slip arcs are independently levelled.
    """
    g = g.sort_values("datetime").copy()
    g["ARC"] = -1
    g["STEC"] = np.nan
    g["LEVEL_OFFSET_TECU"] = np.nan

    if g.empty:
        g["VTEC"] = np.nan
        return g

    # Work day-by-day so the TEC level is independent for each storm-study day.
    if level_mode not in {"daily", "continuous"}:
        raise ValueError("level_mode must be 'daily' or 'continuous'")

    if level_mode == "daily":
        groups = [x for _, x in g.groupby(g["datetime"].dt.floor("D"), sort=True)]
    else:
        groups = [g]

    global_arc = 0

    for day_group in groups:
        ix_day = day_group.index.to_numpy()
        work = day_group.sort_values("datetime")
        ph = work["PHASE_STEC"].to_numpy(float)
        code = work["CODE_STEC"].to_numpy(float)
        tt = work["datetime"].to_numpy()

        arc = np.zeros(len(work), dtype=int)
        if len(work) > 1:
            dph = np.diff(ph)
            dtsec = np.diff(tt) / np.timedelta64(1, "s")
            for i in range(1, len(work)):
                new_arc = (
                    dtsec[i - 1] > 90.0
                    or not np.isfinite(dph[i - 1])
                    or abs(dph[i - 1]) > slip_threshold
                )
                arc[i] = arc[i - 1] + int(new_arc)

        leveled = np.full(len(work), np.nan, dtype=float)
        arc_out = np.full(len(work), -1, dtype=int)

        for a in np.unique(arc):
            local = np.where(arc == a)[0]
            good = np.isfinite(ph[local]) & np.isfinite(code[local])
            if good.sum() < min_level_points:
                continue

            # Median code-phase offset is robust against short code outliers.
            offset = np.nanmedian(code[local][good] - ph[local][good])
            leveled[local] = ph[local] + offset
            arc_out[local] = global_arc
            # Store the actual physical code-phase leveling constant used for
            # this satellite arc; this is a diagnostic, not a TEC rescaling.
            g.loc[work.index[local], "LEVEL_OFFSET_TECU"] = offset
            global_arc += 1

        g.loc[work.index, "STEC"] = leveled
        g.loc[work.index, "ARC"] = arc_out

    g["VTEC"] = g["STEC"] * map_factor(g["Elevation_deg"].to_numpy(float))
    return g

def process_files(obs_files, nav_file, dcb_dir, elevation_mask=10.0, level_mode="daily", slip_threshold=0.75):
    # DCB month from the first observation header.
    first_text=read_text_file(obs_files[0]); first_date=None
    for l in first_text.splitlines()[:120]:
        if "TIME OF FIRST OBS" in l:
            try:
                toks=l.split()
                y,m,d=int(toks[0]),int(toks[1]),int(toks[2])
                first_date=pd.Timestamp(y,m,d)
                break
            except Exception:
                pass
    if first_date is None:
        raise RuntimeError(
            "The RINEX observation header has no readable TIME OF FIRST OBS date. "
            "Use a valid RINEX 2/3 observation file; no guessed date is used for DCB selection."
        )
    p1c1_file,p1p2_file=dcb_download(first_date,dcb_dir)
    p1c1_sat,p1c1_rx=parse_code_dcb(p1c1_file) if p1c1_file else ({},{})
    p1p2_sat,p1p2_rx=parse_code_dcb(p1p2_file) if p1p2_file else ({},{})
    if not p1c1_file or not p1p2_file:
        raise RuntimeError("Required CODE DCB files are unavailable. Put P1C1yymm.DCB(.Z) and P1P2yymm_ALL.DCB(.Z) in the dcb folder, then rerun.")
    eph=parse_nav(nav_file)
    eph_index=build_eph_index(eph)
    allrows=[]
    for obs_path in obs_files:
        log.info("Reading %s", obs_path.name)
        df,rx=read_obs(obs_path)
        if rx is None: raise RuntimeError(f"No receiver XYZ in {obs_path}")
        codes=[]; phases=[]; els=[]; sats=[]; times=[]
        for r in df.itertuples():
            s=r.PRN; sat_dcb=p1p2_sat.get(s,0.0); rx_dcb=p1p2_rx.get(find_station_code(obs_path),0.0); p1c1=p1c1_sat.get(s,0.0)
            codes.append(code_stec_c1p2(r.C1,r.P2,p1c1,sat_dcb,rx_dcb)); phases.append(phase_stec(r.L1,r.L2))
            ee=nearest_eph_indexed(eph_index,s,r.datetime)
            if ee is None: els.append(np.nan)
            else:
                try: els.append(elevation(rx,sat_xyz(ee,r.datetime)))
                except Exception: els.append(np.nan)
            sats.append(s); times.append(r.datetime)
        df["CODE_STEC"]=codes; df["PHASE_STEC"]=phases; df["Elevation_deg"]=els
        df=df[df["Elevation_deg"]>=elevation_mask].copy()
        groups=[g for _,g in df.groupby("PRN",sort=False)]
        # Carrier-phase leveling is independent per satellite arc.  Run those
        # independent jobs concurrently so multi-core CPUs are used without
        # blocking the GUI.  The worker count is capped to avoid oversubscribing
        # laptops and is configurable with GPS_TEC_CPU_WORKERS.
        if groups:
            requested=int(os.environ.get("GPS_TEC_CPU_WORKERS", "0") or 0)
            workers=requested if requested > 0 else min(max(1, (os.cpu_count() or 2) - 1), len(groups), 8)
            if workers > 1 and len(groups) > 1:
                with ThreadPoolExecutor(max_workers=workers) as pool:
                    futs=[pool.submit(process_satellite,g,slip_threshold=slip_threshold,level_mode=level_mode) for g in groups]
                    allrows.extend(f.result() for f in futs)
            else:
                allrows.extend(process_satellite(g, slip_threshold=slip_threshold, level_mode=level_mode) for g in groups)
    if not allrows: raise RuntimeError("No usable satellite arcs after processing.")
    raw=pd.concat(allrows,ignore_index=True).sort_values("datetime")
    raw=raw[np.isfinite(raw["VTEC"])].copy()
    return raw


def epoch_product(raw, interval="5min"):
    """Create a station TEC time series without changing the physical TEC range."""
    x = (
        raw.groupby("datetime")
        .agg(
            STEC=("STEC", "mean"),
            VTEC=("VTEC", "mean"),
            VTEC_STD=("VTEC", "std"),
            STEC_STD=("STEC", "std"),
            NSAT=("PRN", "nunique"),
            MeanElevation=("Elevation_deg", "mean"),
        )
        .sort_index()
    )

    # Mean over each output bin.  Do not interpolate long gaps; missing bins
    # remain missing so the plot does not manufacture TEC observations.
    out = x.resample(interval).mean()
    return out

def daily_leveling_report(raw):
    """Summarize the independent UTC-day carrier-phase leveling."""
    x = raw.dropna(subset=["LEVEL_OFFSET_TECU"]).copy()
    if x.empty:
        return pd.DataFrame()
    x["UTC_Day"] = x["datetime"].dt.floor("D")
    return (
        x.groupby(["UTC_Day", "PRN"])
        .agg(
            Median_Level_Offset_TECU=("LEVEL_OFFSET_TECU", "median"),
            Mean_Level_Offset_TECU=("LEVEL_OFFSET_TECU", "mean"),
            N_Levelled_Points=("STEC", "count"),
            N_Arcs=("ARC", "nunique"),
        )
        .reset_index()
        .sort_values(["UTC_Day", "PRN"])
    )

def mjd_utc(t):
    t=pd.Timestamp(t)
    return (t - pd.Timestamp("1858-11-17")).total_seconds()/86400.0

def write_cmn(raw, output, station, station_lat=None, station_lon=None, station_alt=None):
    """Write a reference-compatible CMN-style ASCII TEC file.

    The current RINEX processor retains elevation and TEC but not azimuth or
    pierce-point coordinates. Those unavailable fields are written as -999
    rather than fabricated values; the scientific TEC fields remain intact.
    """
    output=Path(output); output.parent.mkdir(parents=True,exist_ok=True)
    with output.open("w",encoding="utf-8",newline="") as f:
        f.write(f"{station}, GPS-TEC-DB TEC\n")
        lat="-999" if station_lat is None else f"{float(station_lat):.6f}"
        lon="-999" if station_lon is None else f"{float(station_lon):.6f}"
        alt="-999" if station_alt is None else f"{float(station_alt):.3f}"
        f.write(f"{lat}\t{lon}\t{alt}\n")
        f.write("Jdatet\tTime\tPRN\tAz\tEle\tLat\tLon\tStec\tVtec\tS4\n")
        for r in raw.sort_values("datetime").itertuples():
            t=pd.Timestamp(r.datetime)
            tm=t.hour+t.minute/60+t.second/3600+t.microsecond/3.6e9
            ele=getattr(r,"Elevation_deg",np.nan)
            stec=getattr(r,"STEC",np.nan); vtec=getattr(r,"VTEC",np.nan)
            vals=[mjd_utc(t),tm,str(getattr(r,"PRN","")),-999,
                  ele if np.isfinite(ele) else -999,-999,-999,
                  stec if np.isfinite(stec) else -999,vtec if np.isfinite(vtec) else -999,-999]
            f.write("\t".join(f"{x:.6f}" if isinstance(x,(float,np.floating)) else str(x) for x in vals)+"\n")
    return output

def write_std(prod, output, station_lat=None):
    """Write reference-style mean TEC/std ASCII output at the requested epoch interval."""
    output=Path(output); output.parent.mkdir(parents=True,exist_ok=True)
    with output.open("w",encoding="utf-8") as f:
        for t,r in prod.sort_index().iterrows():
            tt=pd.Timestamp(t); tm=tt.hour+tt.minute/60+tt.second/3600
            mean=r.get("VTEC",np.nan)
            # Epoch product is a mean across satellites; estimate spread from
            # the available per-epoch series when it is present, otherwise -.
            sd=r.get("VTEC_STD",np.nan)
            a="-" if not np.isfinite(mean) else f"{mean:.6f}"
            b="-" if not np.isfinite(sd) else f"{sd:.6f}"
            lat="-" if station_lat is None else f"{float(station_lat):.6f}"
            f.write(f"{tm:.6f}\t{a}\t{b}\t{lat}\n")
    return output

def write_bias_summary(raw, output):
    """Write phase-leveling offsets as a diagnostic, not as a claimed receiver DCB."""
    x=raw.dropna(subset=["LEVEL_OFFSET_TECU"]).copy()
    if x.empty:
        return None
    out=(x.groupby("PRN")["LEVEL_OFFSET_TECU"]
         .agg(["count","median","mean","std"])
         .reset_index())
    out.to_csv(output,index=False)
    return output

def plot_product(prod, station, output, start=None, end=None,
                 phases=None, y_max=50.0, overlay=None, overlay_label="Quiet day"):
    """Publication-style whole-period plot matching the supplied reference figure."""
    fig, ax = plt.subplots(figsize=(15, 5), dpi=160)

    # Normalize all plotting times to UTC-naive timestamps.  RINEX/TEC data
    # may be naive while Kyoto HAPI timestamps are UTC-aware; mixing them
    # causes pandas/Matplotlib comparison errors.
    idx = pd.DatetimeIndex(pd.to_datetime(prod.index, utc=True)).tz_localize(None)
    prod = prod.copy()
    prod.index = idx
    if overlay is not None and len(overlay):
        overlay = overlay.copy()
        overlay.index = pd.DatetimeIndex(pd.to_datetime(overlay.index, utc=True)).tz_localize(None)

    if start is None:
        start = prod.index.min().floor("D")
    else:
        start = (pd.Timestamp(start).tz_convert("UTC").tz_localize(None) if pd.Timestamp(start).tzinfo is not None else pd.Timestamp(start))

    if end is None:
        end = prod.index.max().ceil("D")
    else:
        end = (pd.Timestamp(end).tz_convert("UTC").tz_localize(None) if pd.Timestamp(end).tzinfo is not None else pd.Timestamp(end))

    # Draw storm phases first so the TEC curves remain on top.
    phase_handles = []
    if phases:
        for label, color, a, b in phases:
            a = pd.Timestamp(a)
            b = pd.Timestamp(b)
            if a.tzinfo is not None: a = a.tz_convert("UTC").tz_localize(None)
            if b.tzinfo is not None: b = b.tz_convert("UTC").tz_localize(None)
            if b >= start and a <= end:
                h = ax.axvspan(
                    max(a, start), min(b, end),
                    color=color, alpha=0.28, label=label, zorder=0
                )
                phase_handles.append(h)

    plot_prod = prod.loc[(prod.index >= start) & (prod.index <= end)].copy()
    if plot_prod.empty:
        raise RuntimeError("No TEC samples fall inside the requested plot interval.")

    stec_line, = ax.plot(
        plot_prod.index, plot_prod["STEC"],
        color="#0000B8", linewidth=1.45,
        label="STEC", zorder=3
    )
    vtec_line, = ax.plot(
        plot_prod.index, plot_prod["VTEC"],
        color="#D9534F", linewidth=1.35,
        linestyle="--", label="VTEC", zorder=3
    )
    overlay_line = None
    if overlay is not None and len(overlay):
        overlay_line, = ax.plot(
            overlay.loc[(overlay.index >= start) & (overlay.index <= end)].index,
            overlay.loc[(overlay.index >= start) & (overlay.index <= end)]["VTEC"],
            color="#555555", linewidth=1.15, linestyle="-.",
            label=overlay_label, zorder=2
        )

    ax.set_xlim(start, end)
    ax.set_ylim(0, y_max)
    ax.set_ylabel("TEC (TECU)", fontsize=12)
    ax.set_xlabel("Day of Month", fontsize=12, fontweight="bold")

    span=end-start
    if span <= pd.Timedelta(days=2):
        ax.xaxis.set_major_locator(mdates.HourLocator(byhour=range(0,24,3)))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %H:%M"))
        ax.xaxis.set_minor_locator(mdates.HourLocator(byhour=range(0,24,1)))
    elif span <= pd.Timedelta(days=14):
        ax.xaxis.set_major_locator(mdates.DayLocator(interval=1))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
        ax.xaxis.set_minor_locator(mdates.HourLocator(byhour=[6,12,18]))
    else:
        ax.xaxis.set_major_locator(mdates.DayLocator(interval=max(1,int(np.ceil(span.days/14)))))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
        ax.xaxis.set_minor_locator(mdates.DayLocator(interval=1))

    ax.tick_params(direction="in", top=True, right=True, which="both")
    ax.grid(True, which="major", linestyle=":", linewidth=0.7, alpha=0.65)
    ax.grid(True, which="minor", linestyle=":", linewidth=0.35, alpha=0.25)

    ax.text(
        0.008, 0.92, station,
        transform=ax.transAxes,
        fontsize=12, fontweight="bold", color="navy"
    )

    # Legend order: Initial, Main, Recovery, STEC, VTEC.
    handles = phase_handles + [stec_line, vtec_line]
    if overlay_line is not None:
        handles.append(overlay_line)
    labels = [h.get_label() for h in handles]
    ax.legend(handles, labels, loc="upper right", frameon=True)

    fig.tight_layout()
    fig.savefig(output, bbox_inches="tight")
    plt.close(fig)

def main():
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    ap=argparse.ArgumentParser(description="Complete GPS RINEX -> DCB-corrected STEC/VTEC")
    ap.add_argument("--obs",required=True,help="RINEX observation folder")
    ap.add_argument("--nav",default=None,help="Broadcast GPS navigation file; if omitted it is downloaded automatically")
    ap.add_argument("--dcb-dir",default="dcb",help="CODE DCB cache folder")
    ap.add_argument("--station",default="LOY8")
    ap.add_argument("--elevation-mask",type=float,default=10.0)
    ap.add_argument("--interval",default="5min",help="Output interval, e.g. 30s, 1min, 5min or 15min")
    ap.add_argument("--level-mode",choices=["daily","continuous"],default="daily",help="Carrier-phase leveling mode. Daily is recommended for storm-day studies.")
    ap.add_argument("--slip-threshold",type=float,default=0.75,help="Carrier-phase TEC jump threshold in TECU used for arc splitting")
    ap.add_argument("--start",default="2024-05-08 00:00",help="Plot start UTC")
    ap.add_argument("--end",default="2024-05-15 00:00",help="Plot end UTC; use 2024-05-16 00:00 to show the complete May 15 day")
    ap.add_argument("--y-max",type=float,default=50.0,help="Plot upper TEC limit")
    ap.add_argument("--out",default="output")
    args=ap.parse_args()
    obs_dir=Path(args.obs); files=sorted([
        *obs_dir.glob("*.o"), *obs_dir.glob("*.24o"), *obs_dir.glob("*.rnx"),
        *obs_dir.glob("*.rnx.gz"), *obs_dir.glob("*.crx"), *obs_dir.glob("*.crx.gz"),
        *obs_dir.glob("*.CRX"), *obs_dir.glob("*.CRX.GZ")
    ])
    if not files: raise SystemExit("No RINEX observation files found.")
    nav_file=args.nav
    if nav_file is None:
        # Use the first observation epoch to select the daily navigation file.
        txt=read_text_file(files[0]); date=None
        for line in txt.splitlines()[:100]:
            if "TIME OF FIRST OBS" in line:
                try: date=pd.Timestamp(int(line[0:6]),int(line[6:12]),int(line[12:18])); break
                except Exception: pass
        if date is None:
            raise SystemExit(
                "Cannot determine observation date from TIME OF FIRST OBS. "
                "Supply --nav explicitly and use an observation file with a valid date header."
            )
        nav_file=str(nav_download(date,Path(args.dcb_dir).parent/"nav"))
    raw=process_files(files,nav_file,args.dcb_dir,args.elevation_mask,args.level_mode,args.slip_threshold)
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    raw.to_csv(out/f"{args.station}_satellite_TEC.csv",index=False)
    level_report = daily_leveling_report(raw)
    if not level_report.empty:
        level_report.to_csv(out/f"{args.station}_daily_leveling_report.csv", index=False)
    prod=epoch_product(raw,args.interval); prod.to_csv(out/f"{args.station}_TEC_{args.interval}.csv")
    phases=[
        ("Initial Phase", "#fac7e7", pd.Timestamp("2024-05-10 17:00"), pd.Timestamp("2024-05-10 21:00")),
        ("Main Phase", "#ff2424", pd.Timestamp("2024-05-10 21:00"), pd.Timestamp("2024-05-11 04:00")),
        ("Recovery Phase", "#ffd48a", pd.Timestamp("2024-05-11 04:00"), pd.Timestamp("2024-05-13 18:00")),
    ]
    plot_product(
        prod, args.station,
        out/f"{args.station}_STEC_VTEC_DCB.png",
        start=args.start, end=args.end,
        phases=phases, y_max=args.y_max
    )
    log.info("Saved: %s", out / f"{args.station}_satellite_TEC.csv")
    log.info("Saved: %s", out / f"{args.station}_TEC_{args.interval}.csv")
    log.info("Saved: %s", out / f"{args.station}_STEC_VTEC_DCB.png")

if __name__=="__main__": main()
