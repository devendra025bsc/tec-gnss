from __future__ import annotations
from pathlib import Path
import requests
import numpy as np
import pandas as pd

HAPI = "https://wdc.kugi.kyoto-u.ac.jp/hapi"
UA = {"User-Agent": "GPS-TEC-DB-TEC/2.0 research application"}

def _get(dataset, start, stop, timeout=45):
    p = {"dataset": dataset, "start": pd.Timestamp(start).tz_localize("UTC").isoformat().replace("+00:00","Z"),
         "stop": pd.Timestamp(stop).tz_localize("UTC").isoformat().replace("+00:00","Z"),
         "format": "csv"}
    r = requests.get(HAPI + "/data", params=p, headers=UA, timeout=timeout)
    r.raise_for_status()
    # HAPI CSV commonly has a short comment/header section.
    txt = r.text
    lines = [x for x in txt.splitlines() if x.strip()]
    header_i = next((i for i,x in enumerate(lines) if x.lower().startswith("time,")), None)
    if header_i is None:
        return pd.DataFrame()
    from io import StringIO
    df = pd.read_csv(StringIO("\n".join(lines[header_i:])))
    df["Time"] = pd.to_datetime(df["Time"], utc=True, errors="coerce")
    df = df.set_index("Time")
    for c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")
        df[c] = df[c].replace([99999, 9999, 999], np.nan)
    return df

def fetch_kyoto_indices(day, days_before=1, days_after=1):
    day = pd.Timestamp(day).normalize()
    a, b = day - pd.Timedelta(days=days_before), day + pd.Timedelta(days=1+days_after)
    dst = _get("hour_dst", a, b)
    ae = _get("hour_ae", a, b)
    sym = _get("min_asysym", a, b)
    out = {}
    if not dst.empty:
        out["Dst"] = dst
    if not ae.empty:
        out["AE"] = ae
    if not sym.empty:
        out["ASY_SYM"] = sym
    return out

def storm_phase_table(indices, day):
    """Create objective, data-driven storm activity intervals.

    The thresholds are deliberately explicit and editable. They annotate the
    TEC plot; they never modify TEC values.
    """
    day = pd.Timestamp(day).normalize()
    end = day + pd.Timedelta(days=1)
    rows = []
    dst = indices.get("Dst", pd.DataFrame())
    ae = indices.get("AE", pd.DataFrame())
    if dst.empty:
        return pd.DataFrame(columns=["phase","start","end","criterion"])
    x = dst.loc[(dst.index >= day) & (dst.index < end)].copy()
    col = next((c for c in x.columns if c.lower().startswith("dst")), None)
    if col is None or x.empty:
        return pd.DataFrame(columns=["phase","start","end","criterion"])
    # Simple research annotation: main activity when Dst <= -50 nT.
    # Initial/recovery are bounded by the contiguous excursion.
    active = x[col] <= -50
    if active.any():
        first, last = x.index[active][0], x.index[active][-1] + pd.Timedelta(hours=1)
        rows.append(("Main/Disturbed", first, last, "Kyoto Dst <= -50 nT"))
        pre = max(day, first - pd.Timedelta(hours=6))
        post = min(end, last + pd.Timedelta(hours=12))
        if pre < first:
            rows.insert(0, ("Initial", pre, first, "Window before Dst storm interval"))
        if last < post:
            rows.append(("Recovery", last, post, "Window after Dst storm interval"))
    return pd.DataFrame(rows, columns=["phase","start","end","criterion"])

def choose_quiet_day(month_start, exclude_days=None):
    """Select a quiet comparison day from Kyoto Dst for the same month.

    Uses the day with the largest (least negative) daily-median Dst among
    available days, excluding explicitly supplied storm days. This is a
    transparent fallback when the monthly quiet/disturbed-day table is not
    convenient to parse programmatically.
    """
    exclude = {pd.Timestamp(x).normalize() for x in (exclude_days or [])}
    a = pd.Timestamp(month_start).normalize()
    b = a + pd.offsets.MonthBegin(1)
    dst = _get("hour_dst", a, b)
    if dst.empty:
        return None
    col = next((c for c in dst.columns if c.lower().startswith("dst")), None)
    if col is None:
        return None
    daily = dst[col].resample("1D").median().dropna()
    for idx in daily.sort_values(ascending=False).index:
        if idx.normalize() not in exclude:
            return idx.normalize()
    return None
