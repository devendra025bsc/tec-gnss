from __future__ import annotations

import os
import sys
import traceback
from pathlib import Path


def _app_dir() -> Path:
    """Return a writable directory next to the EXE when possible."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def _log_exception(exc: BaseException) -> Path:
    """Write a startup diagnostic in several safe locations."""
    text = "GPS TEC-DB TEC startup failure\n\n" + "".join(
        traceback.format_exception(type(exc), exc, exc.__traceback__)
    )
    candidates = [
        _app_dir() / "GPS_TEC_DB_TEC_startup_error.txt",
        Path.home() / "GPS_TEC_DB_TEC_startup_error.txt",
        Path(os.environ.get("TEMP", ".")) / "GPS_TEC_DB_TEC_startup_error.txt",
    ]
    for path in candidates:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")
            return path
        except Exception:
            continue
    return candidates[-1]


def main() -> int:
    # PyInstaller one-file applications are unpacked into a temporary folder.
    # Make that location importable explicitly and avoid depending on the
    # user's current working directory.
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            sys.path.insert(0, str(meipass))
        os.chdir(_app_dir())

    try:
        # Required for safe startup when the application is later bundled with
        # multiprocessing-capable scientific libraries.
        import multiprocessing
        multiprocessing.freeze_support()

        from gps_tec_gui import main as gui_main
        gui_main()
        return 0
    except Exception as exc:
        log = _log_exception(exc)
        # Always print the traceback when launched from a console/debug build.
        traceback.print_exc()
        try:
            import tkinter as tk
            from tkinter import messagebox
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror(
                "GPS TEC-DB TEC startup error",
                "The program could not start.\n\n"
                f"Diagnostic file:\n{log}\n\n"
                "If Windows blocked the normal EXE, use the DEBUG launcher "
                "included with this package and send the displayed error.",
            )
            root.destroy()
        except Exception:
            pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
