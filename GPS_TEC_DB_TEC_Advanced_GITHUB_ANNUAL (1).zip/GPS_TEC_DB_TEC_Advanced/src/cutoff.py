from __future__ import annotations
import numpy as np
import pandas as pd

CANDIDATES = (5.0, 7.5, 10.0, 12.5, 15.0, 20.0)

def ecef_to_geodetic(xyz):
    x, y, z = map(float, xyz)
    a, e2 = 6378137.0, 6.69437999014e-3
    lon = np.arctan2(y, x)
    p = np.hypot(x, y)
    lat = np.arctan2(z, p*(1-e2))
    for _ in range(10):
        n = a/np.sqrt(1-e2*np.sin(lat)**2)
        h = p/np.cos(lat)-n
        lat = np.arctan2(z, p*(1-e2*n/(n+h)))
    return np.degrees(lat), np.degrees(lon)

def auto_cutoff(elevations, site_cutoff=None, min_satellites=4):
    """Choose a documented elevation mask from station/data quality.

    If a valid station/site-log cutoff exists, it is respected. Otherwise,
    candidates are scored from actual daily elevation coverage. Low angles
    receive a small noise penalty; a large coverage gain is retained.
    This is a processing heuristic, not a geophysical constant.
    """
    e = np.asarray(elevations, dtype=float)
    e = e[np.isfinite(e)]
    if e.size == 0:
        return float(site_cutoff if site_cutoff is not None else 10.0), pd.DataFrame()
    if site_cutoff is not None and 0 <= float(site_cutoff) <= 30:
        return float(site_cutoff), pd.DataFrame([{"cutoff_deg": float(site_cutoff), "reason":"station metadata"}])
    rows = []
    base = np.mean(e >= 10.0)
    for c in CANDIDATES:
        cov = np.mean(e >= c)
        # Coverage is useful, but low elevations are increasingly vulnerable
        # to multipath/refraction. Penalize masks below 10 degrees rather than
        # automatically selecting the smallest possible angle.
        low_pen = max(0.0, 10.0-c) * 0.05
        score = cov - low_pen
        rows.append({"cutoff_deg": c, "coverage": cov, "score": score})
    tab = pd.DataFrame(rows)
    best = float(tab.loc[tab["score"].idxmax(), "cutoff_deg"])
    # Avoid an over-aggressive change if the improvement is negligible.
    ten = float(tab.loc[tab["cutoff_deg"]==10.0, "score"].iloc[0])
    if best != 10.0 and float(tab["score"].max()) - ten < 0.025:
        best = 10.0
    return best, tab
