from __future__ import annotations
import os
import platform

def cpu_workers(default_cap=8):
    forced = os.environ.get("GPS_TEC_CPU_WORKERS", "").strip()
    if forced.isdigit() and int(forced) > 0:
        return int(forced)
    return min(max(2, os.cpu_count() or 2), default_cap)

def gpu_info():
    # CuPy is optional. GPU use is limited to vector math where it is actually
    # beneficial; RINEX parsing, HTTPS and Matplotlib remain CPU/I/O bound.
    try:
        import cupy as cp
        n = int(cp.cuda.runtime.getDeviceCount())
        if n:
            props = cp.cuda.runtime.getDeviceProperties(0)
            name = props.get("name", b"GPU")
            if isinstance(name, bytes): name = name.decode(errors="ignore")
            return {"available": True, "name": name, "count": n, "backend": "CuPy"}
    except Exception:
        pass
    return {"available": False, "name": "CPU", "count": 0, "backend": "NumPy"}

def runtime_summary():
    g=gpu_info()
    return {"cpu_threads": cpu_workers(), "gpu": g, "python": platform.python_version()}
