from __future__ import annotations
import argparse
import logging
from pathlib import Path
import pandas as pd
import gps_tec_complete as core

log = logging.getLogger(__name__)

def files_for(folder):
    p=Path(folder)
    return sorted(sum(([str(x) for x in p.glob(pat)] for pat in
                       ("*.o","*.24o","*.rnx","*.rnx.gz","*.crx","*.crx.gz","*.CRX","*.CRX.GZ")), []))

def main():
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    ap=argparse.ArgumentParser(description="GPS TEC batch processor: day/month/year")
    ap.add_argument("--obs",required=True)
    ap.add_argument("--nav",required=True)
    ap.add_argument("--dcb-dir",default="dcb")
    ap.add_argument("--station",default="STATION")
    ap.add_argument("--period",choices=["day","month","year"],default="day")
    ap.add_argument("--start",required=True,help="UTC start date")
    ap.add_argument("--end",required=True,help="UTC end date (exclusive)")
    ap.add_argument("--cutoff",default="10")
    ap.add_argument("--interval",default="5min")
    ap.add_argument("--level-mode",default="daily",choices=["daily","continuous"])
    ap.add_argument("--out",default="output")
    a=ap.parse_args()
    files=files_for(a.obs)
    if not files: raise SystemExit("No RINEX observation files found.")
    cutoff=10.0 if a.cutoff.upper()=="AUTO" else float(a.cutoff)
    raw=core.process_files(files,a.nav,a.dcb_dir,cutoff,a.level_mode,0.75)
    raw=raw[(raw.datetime>=pd.Timestamp(a.start))&(raw.datetime<pd.Timestamp(a.end))]
    out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    raw.to_csv(out/f"{a.station}_{a.period}_satellite_TEC.csv",index=False)
    prod=core.epoch_product(raw,a.interval)
    prod.to_csv(out/f"{a.station}_{a.period}_TEC_{a.interval}.csv")
    core.plot_product(prod,a.station,out/f"{a.station}_{a.period}_STEC_VTEC.png",
                      start=a.start,end=a.end,y_max=max(50,float(prod.VTEC.quantile(.995))*1.15 if len(prod) else 50))
    log.info("Completed %s %s → %s", a.period, a.start, a.end)
if __name__=="__main__": main()
