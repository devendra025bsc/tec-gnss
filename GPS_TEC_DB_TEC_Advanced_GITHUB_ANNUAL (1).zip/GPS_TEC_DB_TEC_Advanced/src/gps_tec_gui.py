from __future__ import annotations
import sys, threading, traceback, json, re
from pathlib import Path
from datetime import date, timedelta
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import pandas as pd
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import gps_tec_complete as core
from data_manager import discover_stations, discover_stations_range, download_station_observation, download_navigation, find_station_on_date, get_bkg_station_metadata
from kyoto_indices import fetch_kyoto_indices, storm_phase_table, choose_quiet_day
from cutoff import auto_cutoff, ecef_to_geodetic
from performance import runtime_summary
from github_catalog import load_station_index, search_station_index
from annual_archive import download_station_year

class App:
    def __init__(self, root):
        self.root = root
        root.title("GPS TEC-DB TEC — RINEX / Storm / Kyoto")
        root.geometry("1120x760")
        root.minsize(980, 680)

        self.start_date_var = tk.StringVar(value="2024-05-10")
        self.end_date_var = tk.StringVar(value="2024-05-10")
        self.start_time_var = tk.StringVar(value="00:00")
        self.end_time_var = tk.StringVar(value="23:59")
        self.provider_var = tk.StringVar(value="BKG / IGS-EUREF-MGEX")
        self.station_var = tk.StringVar()
        self.interval_var = tk.StringVar(value="5min")
        self.cutoff_var = tk.StringVar(value="AUTO")
        self.level_var = tk.StringVar(value="daily")
        self.quiet_var = tk.BooleanVar(value=False)
        self.download_var = tk.BooleanVar(value=True)
        self.online_var = tk.BooleanVar(value=True)
        self.station_filter_var = tk.StringVar()
        self.period_var = tk.StringVar(value="Custom")
        self.status = tk.StringVar(value="Choose a UTC date, then search active stations.")
        self.stations = []
        self.last_product = None
        self.last_station = None
        self.last_day = None
        self.last_indices = {}
        self.last_start_utc = None
        self.last_end_utc = None
        self.local_files = []
        self._busy = False

        self._build()

    def _build(self):
        top = ttk.Frame(self.root, padding=10); top.pack(fill="x")
        ttk.Label(top,text="START UTC").grid(row=0,column=0,sticky="w")
        ttk.Entry(top,textvariable=self.start_date_var,width=12).grid(row=0,column=1,padx=4)
        ttk.Entry(top,textvariable=self.start_time_var,width=7).grid(row=0,column=2,padx=4)
        ttk.Label(top,text="END UTC").grid(row=0,column=3,sticky="w",padx=(12,0))
        ttk.Entry(top,textvariable=self.end_date_var,width=12).grid(row=0,column=4,padx=4)
        ttk.Entry(top,textvariable=self.end_time_var,width=7).grid(row=0,column=5,padx=4)
        self.search_btn=ttk.Button(top,text="SEARCH LIVE",command=self.search); self.search_btn.grid(row=0,column=6,padx=7)
        ttk.Button(top,text="ADD LOCAL RINEX",command=self.add_local_files).grid(row=0,column=7,padx=7)
        ttk.Checkbutton(top,text="Live archive",variable=self.online_var).grid(row=0,column=8,padx=7)

        ttk.Label(top,text="Source").grid(row=1,column=0,sticky="w",pady=(7,0))
        ttk.Combobox(top,textvariable=self.provider_var,
                     values=["BKG / IGS-EUREF-MGEX","BKG / IGS","BKG / EUREF","BKG / MGEX"],
                     width=28,state="readonly").grid(row=1,column=1,columnspan=3,sticky="w",pady=(7,0))
        ttk.Label(top,text="Period").grid(row=1,column=4,sticky="e",pady=(7,0))
        ttk.Combobox(top,textvariable=self.period_var,values=["Custom","Day","Month","Year"],width=10,state="readonly").grid(row=1,column=5,padx=4,pady=(7,0))
        ttk.Button(top,text="APPLY",command=self.apply_period).grid(row=1,column=6,padx=4,pady=(7,0))
        ttk.Label(top,text="Station filter").grid(row=1,column=7,sticky="e",pady=(7,0))
        ttk.Entry(top,textvariable=self.station_filter_var,width=16).grid(row=1,column=8,padx=4,pady=(7,0))

        mid = ttk.Frame(self.root,padding=(10,0,10,10)); mid.pack(fill="both",expand=True)
        left = ttk.Frame(mid); left.pack(side="left",fill="both",expand=True)
        right = ttk.Frame(mid); right.pack(side="right",fill="both",expand=True,padx=(12,0))

        ttk.Label(left,text="Active stations for selected day",font=("Segoe UI",11,"bold")).pack(anchor="w")
        cols=("date","station","network","country","position","file")
        self.tree=ttk.Treeview(left,columns=cols,show="headings",height=22)
        headings={"date":"UTC day","station":"Station","network":"Network","country":"Country","position":"XYZ","file":"RINEX file"}
        widths={"date":85,"station":85,"network":75,"country":60,"position":170,"file":280}
        for c in cols:
            self.tree.heading(c,text=headings[c]); self.tree.column(c,width=widths[c],anchor="w")
        self.tree.pack(fill="both",expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        opts=ttk.LabelFrame(right,text="Processing options",padding=10); opts.pack(fill="x")
        ttk.Label(opts,text="Station").grid(row=0,column=0,sticky="w")
        ttk.Entry(opts,textvariable=self.station_var,width=16,state="readonly").grid(row=0,column=1,sticky="w")
        ttk.Label(opts,text="Cutoff").grid(row=1,column=0,sticky="w",pady=6)
        ttk.Combobox(opts,textvariable=self.cutoff_var,
                     values=["AUTO","5","7.5","10","12.5","15","20"],width=13,state="readonly").grid(row=1,column=1,sticky="w")
        ttk.Label(opts,text="TEC interval").grid(row=2,column=0,sticky="w")
        ttk.Combobox(opts,textvariable=self.interval_var,
                     values=["30s","1min","5min","15min"],width=13,state="readonly").grid(row=2,column=1,sticky="w")
        ttk.Label(opts,text="Leveling").grid(row=3,column=0,sticky="w")
        ttk.Combobox(opts,textvariable=self.level_var,
                     values=["daily","continuous"],width=13,state="readonly").grid(row=3,column=1,sticky="w")
        ttk.Checkbutton(opts,text="Download selected RINEX automatically",variable=self.download_var).grid(row=4,column=0,columnspan=2,sticky="w",pady=5)
        ttk.Checkbutton(opts,text="Overlay a Kyoto quiet-day TEC curve",variable=self.quiet_var).grid(row=5,column=0,columnspan=2,sticky="w")

        btns=ttk.Frame(right,padding=(0,12)); btns.pack(fill="x")
        self.process_btn=ttk.Button(btns,text="Process selected station",command=self.process); self.process_btn.pack(fill="x",pady=3)
        ttk.Button(btns,text="Plot current result",command=self.plot_current).pack(fill="x",pady=3)
        ttk.Button(btns,text="PLOT EXISTING TEC CSV / CMN",command=self.plot_existing_file).pack(fill="x",pady=3)
        ttk.Button(btns,text="Download from URL / API",command=self.download_direct_file).pack(fill="x",pady=3)
        ttk.Button(btns,text="GitHub station index + DOWNLOAD FULL YEAR",command=self.open_annual_catalog).pack(fill="x",pady=3)
        ttk.Button(btns,text="Open output folder",command=self.open_output).pack(fill="x",pady=3)

        logf=ttk.LabelFrame(right,text="Processing log",padding=6); logf.pack(fill="both",expand=True)
        self.log=tk.Text(logf,height=18,wrap="word"); self.log.pack(fill="both",expand=True)

        self.progress=ttk.Progressbar(self.root,mode="indeterminate")
        self.progress.pack(fill="x",side="bottom")
        ttk.Label(self.root,textvariable=self.status,relief="sunken",anchor="w").pack(fill="x",side="bottom")
        rt=runtime_summary()
        g=rt["gpu"]
        gpu_name = g["name"] if g["available"] else "not detected (CPU fallback)"
        self.write(f"Performance: CPU workers={rt['cpu_threads']}; GPU={gpu_name}")

    def _set_busy(self, busy, message=None):
        self._busy = bool(busy)
        state = "disabled" if busy else "normal"
        try:
            self.search_btn.configure(state=state)
            self.process_btn.configure(state=state)
        except Exception:
            pass
        if busy:
            self.progress.start(12)
        else:
            self.progress.stop()
        if message:
            self.status.set(message)

    def apply_period(self):
        try:
            d=pd.Timestamp(self.start_date_var.get()).normalize()
            mode=self.period_var.get()
            if mode=="Day":
                e=d+pd.Timedelta(days=1)-pd.Timedelta(minutes=1)
            elif mode=="Month":
                e=d+pd.offsets.MonthBegin(1)-pd.Timedelta(minutes=1)
            elif mode=="Year":
                e=d+pd.offsets.YearBegin(1)-pd.Timedelta(minutes=1)
            else:
                return
            self.start_date_var.set(d.strftime("%Y-%m-%d")); self.start_time_var.set("00:00")
            self.end_date_var.set(e.strftime("%Y-%m-%d")); self.end_time_var.set(e.strftime("%H:%M"))
        except Exception as exc:
            messagebox.showerror("Period",str(exc))

    def write(self,s):
        self.log.insert("end",str(s)+"\n"); self.log.see("end"); self.root.update_idletasks()

    def parse_range(self):
        sd=pd.Timestamp(f"{self.start_date_var.get()} {self.start_time_var.get()}")
        ed=pd.Timestamp(f"{self.end_date_var.get()} {self.end_time_var.get()}")
        if ed <= sd:
            raise ValueError("END UTC must be later than START UTC.")
        return sd, ed

    def parse_date(self):
        return self.parse_range()[0].date()

    def search(self):
        if self._busy:
            return
        try:
            sd,ed=self.parse_range()
        except Exception as exc:
            messagebox.showerror("Date/time",f"Use YYYY-MM-DD and HH:MM in UTC.\\n\\n{exc}"); return
        self._set_busy(True, "Searching official GNSS data-center holdings…")
        if not self.online_var.get():
            self._set_busy(False, "Live search disabled.")
            messagebox.showinfo("Live search disabled",
                                "Enable 'Live archive' to search the official online GNSS archive.")
            return
        self.write(f"LIVE SEARCH: {sd} → {ed} UTC")
        self.write("Searching each UTC day in the requested interval; only files actually present online are returned.")
        threading.Thread(target=self._search_worker,args=(sd,ed),daemon=True).start()

    def _search_worker(self,sd,ed):
        try:
            nets=("IGS","EUREF","MGEX","GREF","IGLOS")
            stations,errors=discover_stations_range(sd.date(),ed.date(),nets)
            filt=self.station_filter_var.get().strip().upper()
            if filt:
                stations=[x for x in stations if filt in x.station.upper() or filt in x.file_name.upper()]
            for st in stations:
                # date is attached by range discovery after each daily listing
                pass
            self.stations=stations
            self.root.after(0,self._fill_stations,stations,errors)
        except Exception as e:
            self.root.after(0,lambda: messagebox.showerror("Station search",str(e)))
            self.root.after(0,lambda: self._set_busy(False, "Station search failed."))
        else:
            self.root.after(0,lambda: self._set_busy(False, "Station search complete."))

    def _fill_stations(self,stations,errors):
        for i in self.tree.get_children(): self.tree.delete(i)
        for i,s in enumerate(stations):
            xyz = "" if s.x is None else f"{s.x:.0f}, {s.y:.0f}, {s.z:.0f}"
            day=getattr(s,"file_period_date","")
            self.tree.insert("", "end", iid=str(i), values=(day,s.station,s.network,s.country,xyz,s.file_name))
        self.write(f"Found {len(stations)} online daily RINEX candidates (metadata is loaded only on selection).")
        for e in errors: self.write("Notice: "+e)
        self.status.set(f"{len(stations)} online RINEX candidates ready.")

    def on_select(self,_=None):
        sel=self.tree.selection()
        if not sel: return
        s=self.stations[int(sel[0])]
        self.station_var.set(s.station)
        # Metadata lookup is intentionally lazy: do not make one HTTP request
        # per station just to populate the initial availability table.
        try:
            meta=get_bkg_station_metadata(s.station)
            s.name=meta.get("name") or meta.get("stationName") or s.name
            s.country=meta.get("country") or meta.get("countryCode") or s.country
            for k in ("x","y","z"):
                try: setattr(s,k,float(meta[k]))
                except Exception: pass
            xyz="" if s.x is None else f"{s.x:.0f}, {s.y:.0f}, {s.z:.0f}"
            self.tree.item(sel[0],values=(getattr(s,"file_period_date", ""),s.station,s.network,s.country,xyz,s.file_name))
        except Exception:
            pass

    def add_local_files(self):
        files = filedialog.askopenfilenames(
            title="Select local RINEX observation file(s)",
            filetypes=[
                ("RINEX / Hatanaka", "*.crx *.crx.gz *.rnx *.rnx.gz *.o *.24o *.d.Z"),
                ("All files", "*.*")
            ])
        if not files:
            return
        self.local_files = [Path(x) for x in files]
        # Populate a local-station row for every selected file.
        self.stations = []
        for f in self.local_files:
            name=f.name.upper()
            m=re.match(r"^([A-Z0-9]{4,9})_",name)
            sid=m.group(1) if m else f.stem[:4].upper()
            from data_manager import Station
            self.stations.append(Station(
                station=sid, provider="LOCAL FILE",
                network="LOCAL", file_url=str(f), file_name=f.name
            ))
        for i in self.tree.get_children():
            self.tree.delete(i)
        for i, st in enumerate(self.stations):
            self.tree.insert("", "end", iid=str(i),
                             values=("LOCAL", st.station, "LOCAL", "", "", st.file_name))
        self.write(f"Loaded {len(self.stations)} local RINEX file(s).")
        self.status.set("Local RINEX mode: select a file and process it.")
        self.download_var.set(False)

    def _selected_station(self):
        sel=self.tree.selection()
        if not sel: raise RuntimeError("Select a station first.")
        return self.stations[int(sel[0])]

    def process(self):
        if self._busy:
            return
        try:
            station=self._selected_station()
            sd,ed=self.parse_range()
            d=pd.Timestamp(getattr(station,"file_period_date",sd.date())).date()
        except Exception as e:
            messagebox.showerror("Selection",str(e)); return
        self._set_busy(True, f"Preparing {station.station} …")
        threading.Thread(target=self._process_worker,args=(station,d,sd,ed),daemon=True).start()

    def _process_worker(self,station,d,requested_start,requested_end):
        try:
            self.root.after(0,lambda:self.status.set(f"Preparing {station.station} …"))
            start_utc=(requested_start.tz_localize("UTC") if requested_start.tzinfo is None else requested_start.tz_convert("UTC"))
            end_utc=(requested_end.tz_localize("UTC") if requested_end.tzinfo is None else requested_end.tz_convert("UTC"))

            # Process every daily RINEX belonging to this station in the requested range.
            if station.provider == "LOCAL FILE":
                matches=[station]
            else:
                matches=[x for x in self.stations if x.station.upper()==station.station.upper()]
                matches=sorted(matches,key=lambda x:getattr(x,"file_period_date",str(d)))
            if not matches:
                matches=[station]

            all_raw=[]
            processed_days=[]
            for item in matches:
                day=pd.Timestamp(getattr(item,"file_period_date",d)).date()
                day_start=pd.Timestamp(day,tz="UTC")
                day_end=day_start+pd.Timedelta(days=1)
                if day_end <= start_utc or day_start >= end_utc:
                    continue
                base=Path.cwd()/f"gps_tec_data/{day:%Y}/{day.timetuple().tm_yday:03d}/{item.station}"
                obsdir=base/"obs"; navdir=base/"nav"; dcb=base/"dcb"
                obsdir.mkdir(parents=True,exist_ok=True); navdir.mkdir(parents=True,exist_ok=True)
                if item.provider == "LOCAL FILE":
                    obs=Path(item.file_url)
                elif self.download_var.get():
                    self.root.after(0,lambda item=item:self.write(f"Downloading {item.file_name} …"))
                    obs=download_station_observation(item,obsdir)
                else:
                    matches_local=list(obsdir.glob("*"))
                    if not matches_local: raise RuntimeError(f"No local observation file cached for {day}.")
                    obs=matches_local[0]
                nav=download_navigation(day,navdir)
                self.root.after(0,lambda day=day:self.write(f"Processing {station.station} {day} with {Path(obs).name}"))
                raw_day=core.process_files([obs],str(nav),str(dcb),10.0 if self.cutoff_var.get()=="AUTO" else float(self.cutoff_var.get()),self.level_var.get(),0.75)
                raw_day["datetime"]=pd.to_datetime(raw_day["datetime"],utc=True)
                raw_day=raw_day[(raw_day["datetime"]>=start_utc)&(raw_day["datetime"]<=end_utc)].copy()
                if not raw_day.empty:
                    all_raw.append(raw_day); processed_days.append(day)

            if not all_raw:
                raise RuntimeError("No usable TEC samples fall inside the requested UTC interval.")
            raw=pd.concat(all_raw,ignore_index=True).sort_values("datetime")

            # Adaptive cutoff is evaluated from actual retained satellite geometry.
            cutoff=self.cutoff_var.get()
            if cutoff=="AUTO":
                cutoff2,table=auto_cutoff(raw["Elevation_deg"].to_numpy())
                cutoff=float(cutoff2)
                self.root.after(0,lambda:self.write(f"Adaptive elevation cutoff: {cutoff:g}°"))
            else:
                cutoff=float(cutoff); table=pd.DataFrame()

            station_meta=get_bkg_station_metadata(station.station) if station.provider != "LOCAL FILE" else {}
            lat=lon=alt=None
            try:
                xyz=[float(station_meta[k]) for k in ("x","y","z")]
                lat,lon=ecef_to_geodetic(xyz); alt=station_meta.get("height")
            except Exception: pass

            out=Path.cwd()/f"gps_tec_data/{processed_days[0]:%Y}/{processed_days[0].timetuple().tm_yday:03d}/{station.station}/output"
            out.mkdir(parents=True,exist_ok=True)
            raw.to_csv(out/f"{station.station}_satellite_TEC.csv",index=False)
            lev=core.daily_leveling_report(raw)
            if not lev.empty: lev.to_csv(out/f"{station.station}_daily_leveling_report.csv",index=False)
            prod=core.epoch_product(raw,self.interval_var.get())
            prod.to_csv(out/f"{station.station}_TEC_{self.interval_var.get()}.csv")
            core.write_cmn(raw,out/f"{station.station}.CMN",station.station,lat,lon,alt)
            core.write_std(prod,out/f"{station.station}.STD",lat)
            core.write_bias_summary(raw,out/f"{station.station}_leveling_diagnostic.csv")

            # Kyoto is annotation/context only; it never rescales TEC.
            self.root.after(0,lambda:self.write("Fetching Kyoto Dst/AE/ASY-SYM indices for storm annotation…"))
            indices=fetch_kyoto_indices(processed_days[0],days_before=0,days_after=max(0,len(processed_days)))
            phases=storm_phase_table(indices,processed_days[0])
            phase_list=[(r.phase,"#f0c0c0",r.start,r.end) for r in phases.itertuples()] if not phases.empty else []
            vv=prod["VTEC"].dropna()
            ymax=max(50.0,float(np.nanpercentile(vv,99.5))*1.15) if len(vv) else 50.0
            png=out/f"{station.station}_TEC_plot.png"
            core.plot_product(prod,station.station,png,start=start_utc,end=end_utc,phases=phase_list,y_max=ymax)
            pd.DataFrame([{"station":station.station,"processed_days":";".join(map(str,processed_days)),"requested_start_utc":str(start_utc),"requested_end_utc":str(end_utc),"cutoff_deg":cutoff,"level_mode":self.level_var.get(),"provider":station.provider,"source_url":station.file_url}]).to_csv(out/"processing_metadata.csv",index=False)

            self.last_product=prod; self.last_station=station.station; self.last_day=processed_days[0]; self.last_indices=indices
            self.last_start_utc=start_utc; self.last_end_utc=end_utc
            self.root.after(0,lambda:self.write(f"Finished {station.station}: {len(processed_days)} day(s). Outputs include CMN, STD, TEC CSV and plot."))
            # Auto-plot: processing always produces and opens the finished TEC figure.
            self.root.after(0,lambda p=png: self._open_plot(p))
            self.root.after(0,lambda:self._set_busy(False, f"Finished {station.station}; {len(processed_days)} day(s), {start_utc} → {end_utc} UTC."))
            self.root.after(0,lambda:messagebox.showinfo("GPS TEC-DB TEC",f"Processing finished.\n\nStation: {station.station}\nDays: {len(processed_days)}\nCutoff: {cutoff:g}°\nOutput: {out}"))
        except Exception as e:
            msg=f"{type(e).__name__}: {e}"
            self.root.after(0,lambda:self.write(msg))
            self.root.after(0,lambda:self._set_busy(False, "Processing failed."))
            self.root.after(0,lambda:messagebox.showerror("Processing error",msg))


    def _open_plot(self, path):
        """Open the generated TEC plot in the default Windows image viewer."""
        try:
            import os
            if Path(path).exists() and hasattr(os, "startfile"):
                os.startfile(str(path))
                self.write(f"Auto-plot opened: {path}")
        except Exception as exc:
            self.write(f"Plot was created but could not be opened automatically: {exc}")

    def plot_current(self):
        if self.last_product is None:
            messagebox.showinfo("Plot","Process a station first."); return
        try:
            out=Path.cwd()/f"gps_tec_data/{self.last_day:%Y}/{self.last_day.timetuple().tm_yday:03d}/{self.last_station}/output"
            phases=storm_phase_table(self.last_indices,self.last_day)
            plist=[(r.phase,"#f0c0c0",r.start,r.end) for r in phases.itertuples()] if not phases.empty else []
            start=self.last_start_utc if self.last_start_utc is not None else pd.Timestamp(self.last_day,tz="UTC")
            end=self.last_end_utc if self.last_end_utc is not None else start+pd.Timedelta(days=1)
            vv=self.last_product["VTEC"].dropna()
            ymax=max(50.0,float(np.nanpercentile(vv,99.5))*1.15) if len(vv) else 50.0
            core.plot_product(self.last_product,self.last_station,out/f"{self.last_station}_TEC_plot.png",
                              start=start,end=end,phases=plist,y_max=ymax)
            self.write("Plot refreshed.")
        except Exception as e: messagebox.showerror("Plot",str(e))


    def plot_existing_file(self):
        """Plot existing TEC CSV/CMN data without downloading or recomputing RINEX."""
        path = filedialog.askopenfilename(
            title="Select existing TEC data",
            filetypes=[("TEC data", "*.csv *.cmn *.CMN *.txt *.tsv"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            file_path = Path(path)
            station = file_path.stem.split("_")[0]
            if file_path.suffix.lower() == ".cmn":
                # Seemala-compatible CMN: three header lines, then 10 columns.
                df = pd.read_csv(file_path, sep=r"\s+", skiprows=3, names=[
                    "Jdatet", "Time", "PRN", "Az", "Ele", "Lat", "Lon", "STEC", "VTEC", "S4"
                ], engine="python")
                df["Time"] = pd.to_numeric(df["Time"], errors="coerce")
                try:
                    base_day = pd.Timestamp(self.start_date_var.get()).normalize()
                except Exception:
                    base_day = pd.Timestamp.today().normalize()
                df["datetime"] = base_day + pd.to_timedelta(df["Time"], unit="h")
                df["Elevation_deg"] = pd.to_numeric(df["Ele"], errors="coerce")
            else:
                df = pd.read_csv(file_path, comment="#")
                lower = {str(c).strip().lower(): c for c in df.columns}
                # Support both full satellite CSV and epoch-product CSV.
                dt_col = next((lower[k] for k in ("datetime", "timestamp", "time_utc", "epoch", "date_time") if k in lower), None)
                if dt_col is None:
                    first = df.columns[0]
                    parsed = pd.to_datetime(df[first], errors="coerce", utc=True)
                    if parsed.notna().sum() > 0:
                        dt_col = first
                    else:
                        raise ValueError("No timestamp column found. Expected datetime/timestamp or a saved datetime index.")
                df["datetime"] = pd.to_datetime(df[dt_col], errors="coerce", utc=True).dt.tz_convert(None)
                aliases = {str(c).strip().lower(): c for c in df.columns}
                stec_col = next((aliases[k] for k in ("stec", "stec_tecu", "slant_tec") if k in aliases), None)
                vtec_col = next((aliases[k] for k in ("vtec", "vtec_tecu", "vertical_tec") if k in aliases), None)
                if stec_col is None or vtec_col is None:
                    raise ValueError("CSV must contain STEC and VTEC columns.")
                df["STEC"] = pd.to_numeric(df[stec_col], errors="coerce")
                df["VTEC"] = pd.to_numeric(df[vtec_col], errors="coerce")
            for col in ("STEC", "VTEC"):
                if col not in df.columns:
                    raise ValueError(f"Missing {col} column in the selected file.")
                df[col] = pd.to_numeric(df[col], errors="coerce")
            df["datetime"] = pd.to_datetime(df["datetime"], errors="coerce", utc=True).dt.tz_convert(None)
            df = df.dropna(subset=["datetime", "STEC", "VTEC"])
            df = df[(df["STEC"] >= 0) & (df["VTEC"] >= 0)]
            if df.empty:
                raise ValueError("No valid non-negative STEC/VTEC rows were found.")
            prod = df.set_index("datetime").sort_index()[["STEC", "VTEC"]]
            if "PRN" in df.columns and "Elevation_deg" in df.columns:
                prod = core.epoch_product(df, self.interval_var.get())
            else:
                prod = prod.resample(self.interval_var.get()).mean()
            out = file_path.with_name(file_path.stem + "_STEC_VTEC_plot.png")
            start = prod.index.min()
            end = prod.index.max() + pd.Timedelta(seconds=1)
            values = prod["VTEC"].dropna()
            ymax = max(10.0, float(np.nanpercentile(values, 99.5)) * 1.15) if len(values) else 50.0
            core.plot_product(prod, station, out, start=start, end=end, y_max=ymax)
            self.last_product = prod
            self.last_station = station
            self.last_day = start.date()
            self.last_indices = {}
            self.last_start_utc = start
            self.last_end_utc = end
            self.write(f"Plotted existing data directly: {file_path}")
            self.write(f"Saved plot: {out}")
            self._open_plot(out)
        except Exception as exc:
            messagebox.showerror("Plot existing TEC data", f"{type(exc).__name__}: {exc}")

    def download_direct_file(self):
        """Download one user-supplied official direct URL using Basic or Bearer auth."""
        win = tk.Toplevel(self.root)
        win.title("Official archive / API direct download")
        win.geometry("700x300")
        win.transient(self.root)
        url_var = tk.StringVar()
        user_var = tk.StringVar()
        secret_var = tk.StringVar()
        auth_var = tk.StringVar(value="None")
        dest_var = tk.StringVar(value=str(Path.cwd() / "downloads"))
        pad = {"padx": 8, "pady": 5}
        ttk.Label(win, text="Direct file URL (official archive/API endpoint)").grid(row=0, column=0, sticky="w", **pad)
        ttk.Entry(win, textvariable=url_var, width=78).grid(row=1, column=0, columnspan=3, sticky="ew", **pad)
        ttk.Label(win, text="Authentication").grid(row=2, column=0, sticky="w", **pad)
        ttk.Combobox(win, textvariable=auth_var, values=["None", "Basic (username/password)", "Bearer token"], state="readonly", width=26).grid(row=2, column=1, sticky="w", **pad)
        ttk.Label(win, text="Username (Basic only)").grid(row=3, column=0, sticky="w", **pad)
        ttk.Entry(win, textvariable=user_var, width=30).grid(row=3, column=1, sticky="w", **pad)
        ttk.Label(win, text="Password / API token").grid(row=4, column=0, sticky="w", **pad)
        ttk.Entry(win, textvariable=secret_var, show="*", width=45).grid(row=4, column=1, columnspan=2, sticky="ew", **pad)
        ttk.Label(win, text="Save folder").grid(row=5, column=0, sticky="w", **pad)
        ttk.Entry(win, textvariable=dest_var, width=58).grid(row=5, column=1, sticky="ew", **pad)
        def browse():
            p = filedialog.askdirectory(title="Choose download folder")
            if p: dest_var.set(p)
        ttk.Button(win, text="Browse", command=browse).grid(row=5, column=2, **pad)
        def download_now():
            import base64
            import urllib.request
            from urllib.parse import urlparse, unquote
            try:
                url = url_var.get().strip()
                if not url.startswith("https://"):
                    raise ValueError("Use an HTTPS URL from the official data provider.")
                headers = {"User-Agent": "GPS-TEC-DB-TEC/3.0"}
                if auth_var.get().startswith("Basic"):
                    token = base64.b64encode((user_var.get() + ":" + secret_var.get()).encode()).decode()
                    headers["Authorization"] = "Basic " + token
                elif auth_var.get() == "Bearer token":
                    headers["Authorization"] = "Bearer " + secret_var.get().strip()
                request = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(request, timeout=90) as response:
                    if response.status != 200:
                        raise RuntimeError(f"Server returned HTTP {response.status}.")
                    data = response.read()
                if not data:
                    raise RuntimeError("The server returned an empty file.")
                name = Path(unquote(urlparse(url).path)).name or "downloaded_gnss_data"
                folder = Path(dest_var.get()).expanduser()
                folder.mkdir(parents=True, exist_ok=True)
                target = folder / name
                target.write_bytes(data)
                self.write(f"Downloaded {len(data):,} bytes from official URL to {target}")
                messagebox.showinfo("Download complete", f"Saved file:\n{target}\n\nSelect it with ADD LOCAL RINEX or plot existing TEC CSV/CMN.")
                win.destroy()
            except Exception as exc:
                messagebox.showerror("Download failed", f"{type(exc).__name__}: {exc}\n\nSome providers require OAuth/browser login or cookies and do not support Basic/Bearer direct downloads.")
        ttk.Button(win, text="DOWNLOAD", command=download_now).grid(row=6, column=1, sticky="e", **pad)
        ttk.Label(win, text="Credentials are used for this download only and are not saved by this application.", wraplength=660).grid(row=7, column=0, columnspan=3, sticky="w", **pad)

    def open_annual_catalog(self):
        """Open GitHub station-index search and official annual archive downloader."""
        win = tk.Toplevel(self.root)
        win.title("GitHub Station Index + Annual RINEX Downloader")
        win.geometry("820x640")
        win.transient(self.root)
        win.grab_set()
        frame = ttk.Frame(win, padding=12); frame.pack(fill="both", expand=True)
        cache_file = Path.home() / ".gps_tec_db_tec" / "cache" / "github_station_index.json"
        url_var = tk.StringVar(value="")
        query_var = tk.StringVar()
        station_var = tk.StringVar(value=self.station_var.get().strip().upper())
        year_var = tk.StringVar(value=str(date.today().year - 1))
        network_var = tk.StringVar(value="IGS")
        out_var = tk.StringVar(value=str(Path.home() / "GPS_TEC_Data"))
        status_var = tk.StringVar(value="Paste a GitHub raw JSON URL to search station metadata. Daily files are verified at the official archive.")
        ttk.Label(frame, text="GitHub raw JSON URL (station metadata index)").grid(row=0,column=0,sticky="w")
        ttk.Entry(frame,textvariable=url_var,width=95).grid(row=1,column=0,columnspan=4,sticky="ew",pady=(3,8))
        ttk.Label(frame,text="Search index").grid(row=2,column=0,sticky="w")
        ttk.Entry(frame,textvariable=query_var,width=28).grid(row=3,column=0,sticky="ew",padx=(0,5))
        results = tk.Listbox(frame,height=8,exportselection=False)
        results.grid(row=4,column=0,columnspan=4,sticky="nsew",pady=6)
        index_rows = []
        def load_index():
            try:
                rows, msg = load_station_index(url_var.get(), cache_file, allow_cached=True)
                index_rows.clear(); index_rows.extend(rows)
                update_results(); status_var.set(msg)
            except Exception as exc:
                messagebox.showerror("GitHub station index", str(exc), parent=win)
                status_var.set("Index load failed; no live station metadata was assumed.")
        def update_results(*_):
            q = query_var.get()
            found = search_station_index(index_rows, q)
            results.delete(0, "end")
            for row in found[:1000]:
                sid = str(row.get("station", "")).upper()
                label = " — ".join(str(row.get(k, "")).strip() for k in ("station", "name", "country", "network") if str(row.get(k, "")).strip())
                results.insert("end", label or sid)
        def choose_result(_=None):
            sel = results.curselection()
            if not sel: return
            found = search_station_index(index_rows, query_var.get())
            if sel[0] < len(found): station_var.set(str(found[sel[0]].get("station", "")).upper())
        ttk.Button(frame,text="LOAD / REFRESH INDEX",command=load_index).grid(row=3,column=1,sticky="w")
        results.bind("<<ListboxSelect>>", choose_result)
        query_var.trace_add("write", update_results)
        ttk.Label(frame,text="Station code").grid(row=5,column=0,sticky="w",pady=(8,0))
        ttk.Entry(frame,textvariable=station_var,width=14).grid(row=6,column=0,sticky="w")
        ttk.Label(frame,text="Year (daily observations)").grid(row=5,column=1,sticky="w",pady=(8,0))
        ttk.Entry(frame,textvariable=year_var,width=12).grid(row=6,column=1,sticky="w")
        ttk.Label(frame,text="Official archive network").grid(row=5,column=2,sticky="w",pady=(8,0))
        ttk.Combobox(frame,textvariable=network_var,values=["IGS","EUREF","MGEX","GREF","IGLOS"],state="readonly",width=12).grid(row=6,column=2,sticky="w")
        ttk.Label(frame,text="Output directory").grid(row=7,column=0,sticky="w",pady=(8,0))
        ttk.Entry(frame,textvariable=out_var,width=70).grid(row=8,column=0,columnspan=3,sticky="ew")
        def choose_dir():
            d = filedialog.askdirectory(title="Choose annual RINEX output directory", parent=win)
            if d: out_var.set(d)
        ttk.Button(frame,text="Browse…",command=choose_dir).grid(row=8,column=3,padx=5)
        progress = ttk.Progressbar(frame,mode="determinate",maximum=366)
        progress.grid(row=9,column=0,columnspan=4,sticky="ew",pady=(12,5))
        ttk.Label(frame,textvariable=status_var,wraplength=770).grid(row=10,column=0,columnspan=4,sticky="w")
        log = tk.Text(frame,height=6,wrap="word"); log.grid(row=11,column=0,columnspan=4,sticky="nsew",pady=(6,0))
        def start_download():
            try:
                sid = station_var.get().strip().upper(); yr = int(year_var.get())
                out = Path(out_var.get()).expanduser()
                if not sid or not out_var.get().strip(): raise ValueError("Station code and output directory are required.")
            except Exception as exc:
                messagebox.showerror("Annual download", str(exc), parent=win); return
            start_btn.configure(state="disabled"); progress.configure(maximum=366 if (yr % 4 == 0 and (yr % 100 != 0 or yr % 400 == 0)) else 365, value=0)
            log.insert("end",f"Starting {sid} for {yr} from official BKG HTTPS archive, network {network_var.get()}\n")
            def on_progress(done,total,msg):
                def update():
                    progress.configure(maximum=total,value=done)
                    status_var.set(f"{done}/{total} days checked — {msg}")
                    if done % 10 == 0 or done == total: log.insert("end",f"{done}/{total}: {msg}\n"); log.see("end")
                win.after(0,update)
            def worker():
                try:
                    manifest = download_station_year(sid,yr,out,network=network_var.get(),workers=6,progress=on_progress)
                    def done():
                        start_btn.configure(state="normal")
                        status_var.set(f"Finished. Manifest: {manifest}")
                        log.insert("end",f"\nManifest saved: {manifest}\n")
                        messagebox.showinfo("Annual download complete",f"Finished checking {sid} for {yr}.\nManifest:\n{manifest}",parent=win)
                    win.after(0,done)
                except Exception as exc:
                    win.after(0,lambda: (start_btn.configure(state="normal"), status_var.set("Annual download failed."), messagebox.showerror("Annual download",str(exc),parent=win)))
            threading.Thread(target=worker,daemon=True).start()
        start_btn = ttk.Button(frame,text="SEARCH OFFICIAL ARCHIVE + DOWNLOAD AVAILABLE DAILY FILES",command=start_download)
        start_btn.grid(row=12,column=0,columnspan=4,sticky="ew",pady=(10,0))
        frame.columnconfigure(0,weight=1); frame.rowconfigure(4,weight=1); frame.rowconfigure(11,weight=1)

    def open_output(self):
        if self.last_day and self.last_station:
            p=Path.cwd()/f"gps_tec_data/{self.last_day:%Y}/{self.last_day.timetuple().tm_yday:03d}/{self.last_station}/output"
        else:
            p=Path.cwd()/ "gps_tec_data"
        p.mkdir(parents=True,exist_ok=True)
        import os
        os.startfile(str(p)) if hasattr(os,"startfile") else None

def main():
    root=tk.Tk()
    App(root)
    root.mainloop()

if __name__=="__main__":
    main()
