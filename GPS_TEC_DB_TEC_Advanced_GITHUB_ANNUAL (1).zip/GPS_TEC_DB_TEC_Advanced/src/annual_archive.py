"""Annual GNSS observation downloader: discover each day at the official archive.

GitHub is used for the searchable station metadata index only. Daily RINEX files
are downloaded from the official BKG HTTPS archive and a CSV manifest records
what was found, downloaded, skipped, or unavailable.
"""
from __future__ import annotations
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, timedelta
from pathlib import Path
from threading import Lock
from typing import Callable
from data_manager import list_bkg_stations, download_station_observation, Station

Progress = Callable[[int, int, str], None]


def _station_for_day(station_id: str, day: date, network: str, timeout: int = 20):
    rows = list_bkg_stations(day, network=network, timeout=timeout)
    wanted = station_id.upper().strip()
    matches = [s for s in rows if s.station.upper() == wanted or s.station.upper()[:4] == wanted[:4]]
    return matches[0] if matches else None


def download_station_year(station_id: str, year: int, output_dir: Path, *,
                          network: str = "IGS", workers: int = 6,
                          progress: Progress | None = None) -> Path:
    """Search all UTC days in a year and download available daily observations.

    Missing days are recorded, not fabricated. Existing non-empty files are skipped.
    Network requests are bounded and use the provider's official daily directory.
    """
    station_id = station_id.strip().upper()
    if not (4 <= len(station_id) <= 9) or not station_id.isalnum():
        raise ValueError("Enter a valid station code (for example NIST, COT1, GUAM or HNLC).")
    if year < 1990 or year > date.today().year + 1:
        raise ValueError("Year is outside the supported GNSS archive range.")
    start, end = date(year, 1, 1), date(year + 1, 1, 1) - timedelta(days=1)
    days = [start + timedelta(days=i) for i in range((end - start).days + 1)]
    output_dir = Path(output_dir) / station_id / str(year)
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = output_dir / f"{station_id}_{year}_manifest.csv"
    rows: list[dict] = []
    lock = Lock()
    completed = 0

    def discover(day: date):
        nonlocal completed
        try:
            station = _station_for_day(station_id, day, network)
            if station is None:
                row = {"date_utc": day.isoformat(), "station": station_id, "network": network,
                       "status": "not_found", "filename": "", "url": "", "bytes": 0, "error": "No matching daily file in archive index"}
            else:
                target = output_dir / station.file_name
                if target.exists() and target.stat().st_size > 0:
                    row = {"date_utc": day.isoformat(), "station": station_id, "network": network,
                           "status": "already_present", "filename": target.name, "url": station.file_url,
                           "bytes": target.stat().st_size, "error": ""}
                else:
                    try:
                        saved = download_station_observation(station, output_dir)
                        row = {"date_utc": day.isoformat(), "station": station_id, "network": network,
                               "status": "downloaded", "filename": saved.name, "url": station.file_url,
                               "bytes": saved.stat().st_size, "error": ""}
                    except Exception as exc:
                        row = {"date_utc": day.isoformat(), "station": station_id, "network": network,
                               "status": "download_failed", "filename": station.file_name, "url": station.file_url,
                               "bytes": 0, "error": str(exc)}
        except Exception as exc:
            row = {"date_utc": day.isoformat(), "station": station_id, "network": network,
                   "status": "search_failed", "filename": "", "url": "", "bytes": 0, "error": str(exc)}
        with lock:
            rows.append(row)
            completed += 1
            if progress:
                progress(completed, len(days), f"{day.isoformat()}: {row['status']}")

    with ThreadPoolExecutor(max_workers=max(1, min(int(workers), 12))) as pool:
        futures = [pool.submit(discover, day) for day in days]
        for future in as_completed(futures):
            future.result()

    rows.sort(key=lambda r: r["date_utc"])
    fields = ["date_utc", "station", "network", "status", "filename", "url", "bytes", "error"]
    with manifest_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return manifest_path
