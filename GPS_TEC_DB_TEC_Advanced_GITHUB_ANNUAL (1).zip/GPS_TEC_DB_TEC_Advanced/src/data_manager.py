from __future__ import annotations
import re
import gzip
from dataclasses import dataclass, asdict
from pathlib import Path
from datetime import date
from urllib.parse import urljoin
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import time
import threading

USER_AGENT = "GPS-TEC-DB-TEC/2.0 (research RINEX/TEC workflow)"

@dataclass
class Station:
    station: str
    provider: str
    network: str = ""
    country: str = ""
    name: str = ""
    x: float | None = None
    y: float | None = None
    z: float | None = None
    file_url: str = ""
    file_name: str = ""
    file_period: str = "01D"
    rinex_version: str = "3"

_tls = threading.local()

def _session():
    # Reuse one HTTP connection pool per worker thread.  The old implementation
    # created a new TCP/TLS session for every request, which made live search
    # noticeably sluggish on multi-network searches.
    s = getattr(_tls, "session", None)
    if s is None:
        s = requests.Session()
        s.headers.update({"User-Agent": USER_AGENT, "Accept-Encoding": "gzip, deflate"})
        adapter = requests.adapters.HTTPAdapter(pool_connections=8, pool_maxsize=8, max_retries=1)
        s.mount("https://", adapter)
        s.mount("http://", adapter)
        _tls.session = s
    return s

def doy(d: date) -> int:
    return d.timetuple().tm_yday

def _station_id_from_rnx3(name: str) -> str:
    # RINEX 3 long name: XXXXXCCC_R_YYYYDDDHHMM_01D_30S_MO.crx.gz
    m = re.match(r"^([A-Z0-9]{9})_", name.upper())
    return m.group(1) if m else name[:4].upper()

def _parse_bkg_index(html: str, base: str, provider="BKG", network=""):
    """Parse the real BKG HTTPS directory index into downloadable RINEX files."""
    out = []
    # BKG directory listings expose filenames as href/text. We accept either.
    hrefs = re.findall(r'href=["\']([^"\']+)["\']', html, re.I)
    texts = re.findall(r'>([^<>]+\.(?:crx\.gz|rnx\.gz|crx|rnx|d\.Z|o))<', html, re.I)
    names = set()
    for x in hrefs + texts:
        x = x.strip().split("?")[0]
        name = x.rsplit("/", 1)[-1]
        if not name or name in (".", ".."):
            continue
        low = name.lower()
        if not any(low.endswith(ext) for ext in (
            ".crx.gz", ".rnx.gz", ".crx", ".rnx", ".d.z", ".o", ".24o"
        )):
            continue
        names.add(name)

    for name in sorted(names):
        low = name.lower()
        # Daily observation files only. Navigation is handled separately.
        if "_01d_" not in low and ".d.z" not in low and not low.endswith(".24o"):
            continue
        if "_mo." not in low and ".d.z" not in low and not low.endswith(".24o"):
            continue

        sid = _station_id_from_rnx3(name)
        if len(sid) < 4:
            sid = name[:4].upper()
        out.append(Station(
            station=sid, provider=provider, network=network,
            file_url=urljoin(base, name), file_name=name, rinex_version="3"
        ))
    return out

def _real_bkg_network_listing(d: date, network: str, timeout=45):
    """Query BKG's actual public HTTPS directory for the selected UTC day."""
    y, dd = d.year, doy(d)
    base = f"https://igs.bkg.bund.de/root_ftp/{network}/obs/{y}/{dd:03d}/"
    r = _session().get(base, timeout=timeout)
    r.raise_for_status()
    return _parse_bkg_index(r.text, base, "BKG", network)

def list_bkg_stations(d: date, network="IGS", timeout=45):
    return _real_bkg_network_listing(d, network, timeout)

def list_bkg_all_networks(d: date, networks=("IGS","EUREF","MGEX","GREF","IGLOS"), timeout=20):
    """Search BKG network directories concurrently for faster live discovery."""
    stations, errors = [], []
    nets = tuple(dict.fromkeys(networks))
    # These are independent HTTPS directory requests, so do them concurrently.
    with ThreadPoolExecutor(max_workers=min(5, len(nets) or 1)) as ex:
        futs = {ex.submit(_real_bkg_network_listing, d, net, timeout): net for net in nets}
        for fut in as_completed(futs):
            net = futs[fut]
            try:
                stations.extend(fut.result())
            except Exception as exc:
                errors.append(f"{net}: {exc}")
    # Prefer IGS > MGEX > EUREF > other network copies.
    priority = {"IGS":0, "MGEX":1, "EUREF":2, "GREF":3, "IGLOS":4}
    unique = {}
    for st in stations:
        old = unique.get(st.station)
        if old is None or priority.get(st.network, 99) < priority.get(old.network, 99):
            unique[st.station] = st
    return sorted(unique.values(), key=lambda x: x.station), errors

def get_bkg_station_metadata(station_id: str, timeout=12, cache_dir=None):
    """Fetch and locally cache BKG station metadata; metadata lookup is lazy."""
    sid = station_id.upper().strip()
    cache_dir = Path(cache_dir or (Path.cwd() / "gps_tec_cache" / "stations"))
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / f"{sid}.json"
    if cache_file.exists():
        try:
            if time.time() - cache_file.stat().st_mtime < 30 * 86400:
                return json.loads(cache_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    u = f"https://igs.bkg.bund.de/api/collections/stations/items/{sid}"
    try:
        r = _session().get(u, timeout=timeout)
        if not r.ok:
            r = _session().get(u + "?uploadInfo=true", timeout=timeout)
        if not r.ok:
            return {}
        j = r.json()
        props = j.get("properties", j if isinstance(j, dict) else {})
        coords = (j.get("geometry") or {}).get("coordinates") if isinstance(j, dict) else None
        if coords and len(coords) >= 3:
            props = dict(props)
            props["x"], props["y"], props["z"] = coords[:3]
        try:
            cache_file.write_text(json.dumps(props, default=str), encoding="utf-8")
        except Exception:
            pass
        return props
    except Exception:
        return {}


def enrich_stations(stations):
    out = []
    for s in stations:
        meta = get_bkg_station_metadata(s.station)
        s.name = meta.get("name") or meta.get("stationName") or ""
        s.country = meta.get("country") or meta.get("countryCode") or ""
        s.network = meta.get("network") or meta.get("networks") or s.network
        for k in ("x", "y", "z"):
            try:
                setattr(s, k, float(meta[k]))
            except Exception:
                pass
        out.append(s)
    return out

def discover_stations_range(start_day: date, end_day: date,
                            networks=("IGS","EUREF","MGEX","GREF","IGLOS")):
    """Fast multi-day discovery: UTC days and networks are queried concurrently."""
    days=[]
    d=start_day
    while d <= end_day:
        days.append(d)
        d = d.fromordinal(d.toordinal()+1)
    results=[]; errors=[]
    nets=tuple(dict.fromkeys(networks))
    jobs=[(d,n) for d in days for n in nets]
    with ThreadPoolExecutor(max_workers=min(12, max(1,len(jobs)))) as ex:
        futs={ex.submit(_real_bkg_network_listing,d,n,20):(d,n) for d,n in jobs}
        for fut in as_completed(futs):
            d,n=futs[fut]
            try:
                results.extend(fut.result())
            except Exception as exc:
                errors.append(f"{d} {n}: {exc}")
    priority={"IGS":0,"MGEX":1,"EUREF":2,"GREF":3,"IGLOS":4}
    unique={}
    for st in results:
        key=(st.station.upper(), getattr(st,"file_period_date",""))
        old=unique.get(key)
        if old is None or priority.get(st.network,99)<priority.get(old.network,99):
            unique[key]=st
    return sorted(unique.values(), key=lambda x:(x.station,getattr(x,"file_period_date",""))), errors

def discover_stations(d: date, networks=("IGS","EUREF","MGEX","GREF","IGLOS"), enrich=False):
    """Live online station discovery for the exact selected UTC day.

    A station is returned only when the requested archive actually exposes a
    daily observation file for that date. This is intentionally different from
    a static list of currently active stations.
    """
    stations, errors = list_bkg_all_networks(d, networks)
    if enrich and stations:
        stations = enrich_stations(stations)
    return stations, errors

def find_station_on_date(station_id: str, d: date, networks=("IGS","EUREF","MGEX","GREF","IGLOS")):
    """Find the requested station's real daily RINEX observation file on a UTC date.

    This is used by the optional Kyoto quiet-day overlay.  The lookup uses the
    live BKG archive for the requested date rather than a static station list.
    Metadata enrichment is deliberately skipped here because only the file URL
    is required for downloading and processing the quiet-day observation.
    """
    target = station_id.upper().strip()
    stations, _errors = list_bkg_all_networks(d, networks=networks)
    exact = [s for s in stations if s.station.upper() == target]
    if exact:
        return exact[0]
    # RINEX station identifiers can occasionally be represented by the four-
    # character site code, so allow that as a fallback.
    short = target[:4]
    for s in stations:
        if s.station.upper()[:4] == short:
            return s
    return None

def download_file(url: str, target: Path, timeout=90):
    target.parent.mkdir(parents=True, exist_ok=True)
    with _session().get(url, stream=True, timeout=timeout) as r:
        r.raise_for_status()
        with open(target, "wb") as f:
            for chunk in r.iter_content(1024 * 1024):
                if chunk:
                    f.write(chunk)
    return target

def download_station_observation(station: Station, out_dir: Path):
    return download_file(station.file_url, Path(out_dir) / station.file_name)

def bkg_daily_nav_url(d: date):
    y, dd = d.year, doy(d)
    return f"https://igs.bkg.bund.de/root_ftp/IGS/BRDC/{y}/{dd:03d}/BRDC00IGS_R_{y}{dd:03d}0000_01D_MN.rnx.gz"

def bkg_daily_gps_nav_url(d: date):
    y, dd = d.year, doy(d)
    return f"https://igs.bkg.bund.de/root_ftp/IGS/BRDC/{y}/{dd:03d}/BRDC00WRD_R_{y}{dd:03d}0000_01D_GN.rnx.gz"

def download_navigation(d: date, out_dir: Path):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    names = [
        bkg_daily_nav_url(d),
        bkg_daily_gps_nav_url(d),
    ]
    last = None
    for u in names:
        target = out_dir / u.rsplit("/", 1)[-1]
        try:
            return download_file(u, target)
        except Exception as exc:
            last = exc
    raise RuntimeError(f"Unable to download BKG broadcast navigation for {d}: {last}")
