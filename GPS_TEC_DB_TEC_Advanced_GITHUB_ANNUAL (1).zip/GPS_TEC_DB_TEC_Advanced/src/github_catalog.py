"""GitHub-hosted station index support.

The index is metadata only. Observation files remain at their official archive;
this module never mirrors RINEX observations into GitHub.
"""
from __future__ import annotations
import json
import time
from pathlib import Path
from typing import Any
import requests

USER_AGENT = "GPS-TEC-DB-TEC/3.0 (GNSS research station catalogue)"
DEFAULT_INDEX_URL = ""


def load_station_index(index_url: str, cache_file: Path, *, timeout: int = 15,
                       allow_cached: bool = True) -> tuple[list[dict[str, Any]], str]:
    """Load JSON station index from a user-supplied GitHub raw URL.

    Accepted format: {"version": 1, "stations": [{"station":"NIST", ...}]}.
    A plain JSON list is accepted too. Cached metadata is used only when explicitly
    allowed; archive availability is always checked against the official provider.
    """
    url = (index_url or "").strip()
    cache_file = Path(cache_file)
    if url:
        try:
            response = requests.get(url, timeout=timeout, headers={"User-Agent": USER_AGENT})
            response.raise_for_status()
            payload = response.json()
            rows = payload if isinstance(payload, list) else payload.get("stations", [])
            if not isinstance(rows, list):
                raise ValueError("Index JSON must be a list or an object containing a 'stations' list.")
            cleaned = [r for r in rows if isinstance(r, dict) and str(r.get("station", "")).strip()]
            cache_file.parent.mkdir(parents=True, exist_ok=True)
            cache_file.write_text(json.dumps({"fetched_at": time.time(), "source": url,
                                              "stations": cleaned}, indent=2), encoding="utf-8")
            return cleaned, f"GitHub index loaded: {len(cleaned)} stations"
        except Exception as exc:
            if not allow_cached:
                raise RuntimeError(f"Could not load GitHub station index: {exc}") from exc
            # Explicitly report cache usage; this is metadata only, never proof of data availability.
            if not cache_file.exists():
                raise RuntimeError(f"GitHub index unavailable and no local cache exists: {exc}") from exc
            try:
                cached = json.loads(cache_file.read_text(encoding="utf-8"))
                rows = cached.get("stations", [])
                return rows, f"GitHub unavailable; using cached station metadata ({len(rows)} entries). Live archive availability is still verified."
            except Exception as cache_exc:
                raise RuntimeError(f"GitHub index failed ({exc}); cache is invalid ({cache_exc})") from cache_exc
    if allow_cached and cache_file.exists():
        payload = json.loads(cache_file.read_text(encoding="utf-8"))
        rows = payload.get("stations", [])
        return rows, f"Using local cached station metadata ({len(rows)} entries); no GitHub URL configured."
    raise ValueError("Enter a GitHub raw JSON URL or provide a local cached index.")


def search_station_index(rows: list[dict[str, Any]], query: str) -> list[dict[str, Any]]:
    q = (query or "").strip().casefold()
    if not q:
        return sorted(rows, key=lambda r: str(r.get("station", "")).upper())
    fields = ("station", "name", "country", "network", "city", "provider")
    return [r for r in rows if any(q in str(r.get(k, "")).casefold() for k in fields)]
